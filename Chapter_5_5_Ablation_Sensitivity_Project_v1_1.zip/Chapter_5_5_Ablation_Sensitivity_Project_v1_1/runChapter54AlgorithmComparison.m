%% runChapter54AlgorithmComparison.m
% Chapter 5.4 Comparison with Multi-objective Optimization Algorithms
%
% Algorithms:
%   TNSAOO, NSGA-II, MOPSO, NSWOA, MOEA/D
%
% Important fairness rule:
% For the same field and seed, all algorithms use exactly the same generated
% UAV-UGV prescription-operation scenario env. Only the optimizer changes.
%
% Outputs:
%   data/ch5_4_raw_results.csv
%   data/ch5_4_archive_objectives_raw.csv
%   data/ch5_4_archive_history_raw.csv
%   data/ch5_4_metrics_by_run.csv
%   data/ch5_4_summary_by_algorithm.csv
%   data/ch5_4_summary_by_case_algorithm.csv
%   data/plot_data_*.csv
%   figures/*.png/*.fig/*.pdf
%   mat/chapter5_4_workspace.mat

clear; clc; close all;
addpath(genpath(fullfile(pwd, 'src')));

cfgBase = config();
cfgBase = ensureChapter54Config(cfgBase);

timestamp = datestr(now, 'yyyymmdd_HHMMSS');
outDir = fullfile(cfgBase.paths.resultsDir, [cfgBase.chapter54.outputPrefix, '_', timestamp]);
dataDir = fullfile(outDir, 'data');
figDir = fullfile(outDir, 'figures');
matDir = fullfile(outDir, 'mat');
mkdirIfNeeded(outDir); mkdirIfNeeded(dataDir); mkdirIfNeeded(figDir); mkdirIfNeeded(matDir);

diary(fullfile(outDir, 'chapter5_4_run_log.txt'));

caseFiles = cfgBase.chapter54.caseFiles;
caseNames = cfgBase.chapter54.caseNames;
algorithms = cfgBase.chapter54.algorithms;
seeds = cfgBase.chapter54.seeds(:).';

fprintf('=== Chapter 5.4 Multi-objective Algorithm Comparison ===\n');
fprintf('Cases=%d | Algorithms=%d | Seeds=%d\n', numel(caseFiles), numel(algorithms), numel(seeds));
fprintf('Output directory: %s\n', outDir);

runRows = struct([]);
archiveRows = struct([]);
historyRows = struct([]);
runCounter = 0;
archiveCounter = 0;
histCounter = 0;

rawCsv = fullfile(dataDir, 'ch5_4_raw_results.csv');
archiveCsv = fullfile(dataDir, 'ch5_4_archive_objectives_raw.csv');
historyCsv = fullfile(dataDir, 'ch5_4_archive_history_raw.csv');

for c = 1:numel(caseFiles)
    for s = 1:numel(seeds)
        % Build the same scenario once for all algorithms.
        scenarioCfg = cfgBase;
        scenarioCfg.data.fieldFileName = caseFiles{c};
        scenarioCfg.seed = seeds(s);
        scenarioCfg.env.nSprayTasks = cfgBase.chapter54.nSprayTasks(c);
        scenarioCfg.env.nFertTasks = cfgBase.chapter54.nFertTasks(c);
        scenarioCfg.env.nObstacles = cfgBase.chapter54.nObstacles(c);
        scenarioCfg.env.nRefillCandidates = cfgBase.chapter54.nRefillCandidates(c);
        scenarioCfg.env.includeKnownFieldObstacles = cfgBase.chapter54.includeKnownFieldObstacles;

        rng(seeds(s) + 1000*c, 'twister');
        fprintf('\n--- Scenario: %s | %s | seed=%d ---\n', caseNames{c}, caseFiles{c}, seeds(s));
        env = generateEnvironment(scenarioCfg);

        if cfgBase.chapter54.savePerRunMat
            save(fullfile(matDir, sprintf('env_case_%02d_seed_%d.mat', c, seeds(s))), 'env', 'scenarioCfg');
        end

        for a = 1:numel(algorithms)
            algName = algorithms{a};
            runCounter = runCounter + 1;

            cfg = scenarioCfg;
            cfg.alg.popSize = cfgBase.chapter54.popSize;
            cfg.alg.maxIter = cfgBase.chapter54.maxIter;
            cfg.alg.archiveSize = cfgBase.chapter54.archiveSize;

            rng(seeds(s) + 1000*c + 97*a, 'twister');

            fprintf('\n[%d] Algorithm=%s | Case=%d | seed=%d\n', runCounter, algName, c, seeds(s));

            try
                ticRun = tic;
                [archive, history] = runChapter54Optimizer(algName, env, cfg);
                runtime = toc(ticRun);
                best = selectCompromiseSolution(archive);
                geo = validateScenarioGeometry(env, cfg);
                row = makeChapter54RunRecord(runCounter, c, caseNames{c}, algName, seeds(s), env, best, archive, history, cfg, runtime, geo, 'ok', '');

                % Archive rows.
                newArc = makeChapter54ArchiveRows(runCounter, c, caseNames{c}, algName, seeds(s), archive);
                if ~isempty(newArc)
                    archiveRows = appendStructArray(archiveRows, newArc); %#ok<AGROW>
                    archiveCounter = archiveCounter + numel(newArc);
                end

                % Iteration-history archive rows.
                newHist = makeChapter54HistoryRows(runCounter, c, caseNames{c}, algName, seeds(s), history);
                if ~isempty(newHist)
                    historyRows = appendStructArray(historyRows, newHist); %#ok<AGROW>
                    histCounter = histCounter + numel(newHist);
                end

                fprintf('OK | archive=%d | T=%.2f E=%.2f D=%.2f | runtime=%.2fs\n', ...
                    numel(archive), row.makespan, row.weightedEnergy, row.driftPenalty, runtime);

                if cfgBase.chapter54.savePerRunMat
                    save(fullfile(matDir, sprintf('run_%03d_case_%02d_%s_seed_%d.mat', runCounter, c, algName, seeds(s))), ...
                        'cfg', 'env', 'archive', 'history', 'best', 'row');
                end

            catch ME
                row = makeChapter54FailedRecord(runCounter, c, caseNames{c}, algName, seeds(s), scenarioCfg, ME);
                fprintf('FAILED | %s\n', ME.message);
            end

            runRows = appendStructArray(runRows, row); %#ok<AGROW>

            % Incremental saving.
            writetable(struct2table(runRows, 'AsArray', true), rawCsv);
            if ~isempty(archiveRows)
                writetable(struct2table(archiveRows, 'AsArray', true), archiveCsv);
            end
            if ~isempty(historyRows)
                writetable(struct2table(historyRows, 'AsArray', true), historyCsv);
            end
        end
    end
end

Traw = struct2table(runRows, 'AsArray', true);
writetable(Traw, rawCsv);

Tarchive = struct2table(archiveRows, 'AsArray', true);
writetable(Tarchive, archiveCsv);

Thistory = struct2table(historyRows, 'AsArray', true);
writetable(Thistory, historyCsv);

% Compute HV, IGD, spacing, summaries, and plot data.
[metricsByRun, summaryAlg, summaryCaseAlg, plotData] = analyzeChapter54Results(Traw, Tarchive, Thistory, cfgBase, dataDir);

% Draw figures.
plotChapter54Figures(plotData, figDir);

if cfgBase.chapter54.saveWorkspace
    save(fullfile(matDir, 'chapter5_4_workspace.mat'), ...
        'cfgBase', 'Traw', 'Tarchive', 'Thistory', 'metricsByRun', 'summaryAlg', 'summaryCaseAlg', 'plotData');
end

fprintf('\n=== Chapter 5.4 finished ===\n');
fprintf('Data: %s\n', dataDir);
fprintf('Figures: %s\n', figDir);
diary off;

function mkdirIfNeeded(p)
if ~exist(p, 'dir'), mkdir(p); end
end
