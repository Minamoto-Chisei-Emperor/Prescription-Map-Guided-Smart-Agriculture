%% runChapter55AblationSensitivity.m
% Chapter 5.5 Ablation and Sensitivity Analysis
%
% This script runs three experiment blocks:
%   1) Ablation study: TNSAOO, NSAOO, Independent
%   2) TIS-control sensitivity: cfg.alg.tisProbability
%   3) Safety-distance sensitivity: cfg.conflict.safetyDistance = 2, 5, 8, 10 m
%
% Notes:
%   - TIS control parameter in the current code is cfg.alg.tisProbability.
%   - The current default TIS probability is 0.65.
%   - The current default safety distance is 8.0 m.
%   - Population size and maximum iterations are kept fixed, because they are
%     experimental budget settings rather than sensitivity factors here.

clear; clc; close all;
addpath(genpath(fullfile(pwd, 'src')));

cfgBase = config();
cfgBase = ensureChapter55Config(cfgBase);

timestamp = datestr(now, 'yyyymmdd_HHMMSS');
outDir = fullfile(cfgBase.paths.resultsDir, [cfgBase.chapter55.outputPrefix, '_', timestamp]);
dataDir = fullfile(outDir, 'data');
figDir = fullfile(outDir, 'figures');
matDir = fullfile(outDir, 'mat');
mkdirIfNeeded(outDir); mkdirIfNeeded(dataDir); mkdirIfNeeded(figDir); mkdirIfNeeded(matDir);

diary(fullfile(outDir, 'chapter5_5_run_log.txt'));

fprintf('=== Chapter 5.5 Ablation and Sensitivity Analysis ===\n');
fprintf('Output directory: %s\n', outDir);
fprintf('Cases=%d | Seeds=%d\n', numel(cfgBase.chapter55.caseFiles), numel(cfgBase.chapter55.seeds));
fprintf('Ablation methods: %s\n', strjoin(string(cfgBase.chapter55.ablationMethods), ', '));
fprintf('TIS probability values: %s\n', mat2str(cfgBase.chapter55.tisProbabilityValues));
fprintf('Safety distance values: %s m\n', mat2str(cfgBase.chapter55.safetyDistanceValues));

conditions = getChapter55Conditions(cfgBase);
fprintf('Total conditions per case-seed: %d\n', numel(conditions));

[Traw, Tarchive, Thistory] = runChapter55Core(cfgBase, conditions, outDir);

rawCsv = fullfile(dataDir, 'ch5_5_raw_results.csv');
archiveCsv = fullfile(dataDir, 'ch5_5_archive_objectives_raw.csv');
historyCsv = fullfile(dataDir, 'ch5_5_archive_history_raw.csv');
writetable(Traw, rawCsv);
writetable(Tarchive, archiveCsv);
writetable(Thistory, historyCsv);

[metricsByRun, summaryByCondition, summaryByCaseCondition, plotData] = analyzeChapter55Results(Traw, Tarchive, cfgBase, dataDir);
plotChapter55Figures(plotData, figDir);

if cfgBase.chapter55.saveWorkspace
    save(fullfile(matDir, 'chapter5_5_workspace.mat'), ...
        'cfgBase', 'conditions', 'Traw', 'Tarchive', 'Thistory', ...
        'metricsByRun', 'summaryByCondition', 'summaryByCaseCondition', 'plotData');
end

fprintf('\n=== Chapter 5.5 finished ===\n');
fprintf('Data: %s\n', dataDir);
fprintf('Figures: %s\n', figDir);
diary off;

function mkdirIfNeeded(p)
if ~exist(p, 'dir'), mkdir(p); end
end
