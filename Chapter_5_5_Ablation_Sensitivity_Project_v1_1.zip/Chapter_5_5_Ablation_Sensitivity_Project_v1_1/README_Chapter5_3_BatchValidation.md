# Chapter 5.3 Batch Validation v1.0

This package adds a complete batch-validation workflow for Section 5.3.

## Entry script

Run in MATLAB from the project root:

```matlab
runChapter53BatchValidation
```

## Experimental purpose

The script is designed around four questions:

1. Can the method run stably on different real field boundaries?
2. Is there a reasonable relationship between field area and operation cost?
3. Does field shape complexity affect path efficiency?
4. Are UAV-UGV conflict counts controllable in batch validation?

## Default settings

- 30 real agricultural field boundaries.
- 3 random seeds: 2026, 2027, 2028.
- TNSAOO only.
- popSize = 20, maxIter = 20.
- Area-adaptive task generation:
  - small fields: 4 spraying + 4 fertilization patches;
  - medium fields: 6 + 6 patches;
  - large fields: 8 + 8 patches.

## Geometry constraints

The scenario generator preserves:

- no task generation inside obstacles;
- no spraying-spraying overlap;
- no fertilization-fertilization overlap;
- spraying-fertilization overlap is allowed;
- refill stations and depot are generated in the operable region.

## Saved data

All outputs are written to:

```text
results/chapter5_3_batch_validation_yyyymmdd_HHMMSS/
```

Important data files:

```text
data/batch_results_raw.csv
data/summary_by_field.csv
data/summary_overall.csv
data/selected_fields.csv
data/field_selection_candidates.csv
data/plot_data_objective_distribution.csv
data/plot_data_area_cost_relationship.csv
data/plot_data_shape_efficiency.csv
data/plot_data_conflict_distribution_raw.csv
data/plot_data_conflict_count_histogram.csv
mat/chapter5_3_workspace.mat
```

## Saved figures

```text
figures/figure_ch5_3_objective_distribution.png/.fig/.pdf
figures/figure_ch5_3_area_cost_relationship.png/.fig/.pdf
figures/figure_ch5_3_shape_efficiency.png/.fig/.pdf
figures/figure_ch5_3_conflict_distribution.png/.fig/.pdf
```

All figures use Times New Roman, large labels, and a calm pastel scientific color palette.

## Quick test

For a quick dry run, open `config.m` and set:

```matlab
cfg.chapter53.quickTest = true;
```

Then rerun:

```matlab
runChapter53BatchValidation
```
