%% runChapter55AblationStudy.m
% Run only Chapter 5.5.1 ablation study.
% Methods: TNSAOO, NSAOO, Independent.

clear; clc; close all;
addpath(genpath(fullfile(pwd, 'src')));

cfgBase = config();
cfgBase = ensureChapter55Config(cfgBase);

timestamp = datestr(now, 'yyyymmdd_HHMMSS');
outDir = fullfile(cfgBase.paths.resultsDir, ['chapter5_5_ablation_only_', timestamp]);
dataDir = fullfile(outDir, 'data');
figDir = fullfile(outDir, 'figures');
matDir = fullfile(outDir, 'mat');
mkdirIfNeeded(outDir); mkdirIfNeeded(dataDir); mkdirIfNeeded(figDir); mkdirIfNeeded(matDir);

diary(fullfile(outDir, 'chapter5_5_ablation_run_log.txt'));

conditionsAll = getChapter55Conditions(cfgBase);
conditions = conditionsAll(string({conditionsAll.experimentType}) == "ablation");

[Traw, Tarchive, Thistory] = runChapter55Core(cfgBase, conditions, outDir);
writetable(Traw, fullfile(dataDir, 'ch5_5_raw_results.csv'));
writetable(Tarchive, fullfile(dataDir, 'ch5_5_archive_objectives_raw.csv'));
writetable(Thistory, fullfile(dataDir, 'ch5_5_archive_history_raw.csv'));

[metricsByRun, summaryByCondition, summaryByCaseCondition, plotData] = analyzeChapter55Results(Traw, Tarchive, cfgBase, dataDir);
plotChapter55Figures(plotData, figDir);

save(fullfile(matDir, 'chapter5_5_ablation_workspace.mat'), ...
    'cfgBase', 'conditions', 'Traw', 'Tarchive', 'Thistory', ...
    'metricsByRun', 'summaryByCondition', 'summaryByCaseCondition', 'plotData');

fprintf('\nChapter 5.5 ablation-only run finished.\n');
diary off;

function mkdirIfNeeded(p)
if ~exist(p, 'dir'), mkdir(p); end
end
