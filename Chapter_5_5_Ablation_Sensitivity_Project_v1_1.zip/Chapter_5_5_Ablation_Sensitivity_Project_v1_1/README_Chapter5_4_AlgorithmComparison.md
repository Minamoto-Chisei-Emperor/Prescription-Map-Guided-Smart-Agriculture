# Chapter 5.4 Algorithm Comparison v1.0

This package adds the complete code for Section 5.4:

**Comparison with Multi-objective Optimization Algorithms**

Algorithms included:

- TNSAOO
- NSGA-II
- MOPSO
- NSWOA
- MOEA/D

## Entry script

Run from the MATLAB project root:

```matlab
runChapter54AlgorithmComparison
```

## Default experimental setting

The default comparison uses the four representative field cases:

```text
ee_field_9.wkt
lt_field_258.wkt
nl_field_24.wkt
nl_field_54.wkt
```

Default algorithms and budget:

```text
Algorithms: TNSAOO, NSGA-II, MOPSO, NSWOA, MOEA/D
Seeds: 2026, 2027, 2028, 2029, 2030
popSize = 20
maxIter = 20
archiveSize = 50
```

This gives:

```text
4 cases × 5 algorithms × 5 seeds = 100 runs
```

For a formal final run, you can increase `cfg.chapter54.seeds` to 10 seeds in `config.m`.

## Fairness design

For each field and random seed, the scenario `env` is generated once and then reused by all algorithms. Therefore, all algorithms share the same:

- field boundary;
- spraying prescription patches;
- fertilization prescription patches;
- obstacles;
- refill candidates;
- depot;
- lower-layer evaluation method.

Only the upper-layer multi-objective optimizer changes.

## Saved data

All results are saved under:

```text
results/chapter5_4_algorithm_comparison_yyyymmdd_HHMMSS/
```

Important output files:

```text
data/ch5_4_raw_results.csv
data/ch5_4_archive_objectives_raw.csv
data/ch5_4_archive_history_raw.csv
data/ch5_4_metrics_by_run.csv
data/ch5_4_summary_by_algorithm.csv
data/ch5_4_summary_by_case_algorithm.csv
data/plot_data_ch5_4_metric_distributions.csv
data/plot_data_ch5_4_pareto_representative_case.csv
data/plot_data_ch5_4_hv_convergence.csv
mat/chapter5_4_workspace.mat
```

## Figures

The plotting functions generate:

```text
figures/figure_ch5_4_hv_igd_distribution.png/.fig/.pdf
figures/figure_ch5_4_compromise_objectives_runtime.png/.fig/.pdf
figures/figure_ch5_4_pareto_representative_case.png/.fig/.pdf
figures/figure_ch5_4_hv_convergence.png/.fig/.pdf
```

The figure style uses Times New Roman, large labels, and a muted warm scientific palette that differs from Chapter 5.3.

## Metrics

The code computes final Pareto-set quality metrics:

- HV, higher is better;
- IGD, lower is better;
- Spacing, lower is more uniform.

For HV and IGD, objectives are normalized per field case using the union of final archive points from all algorithms and seeds. The IGD reference front is approximated by the nondominated union of all final archive solutions for the same field case.

## Notes

- NSGA-II, MOPSO, NSWOA and MOEA/D are implemented using the same random-key encoding, decoder, lower-layer path evaluation and objective functions as TNSAOO.
- The purpose is not to show that TNSAOO is best in every single objective, but to evaluate overall Pareto-set quality and compromise-solution quality under a fair computational budget.
