# Chapter 5.5 Ablation and Sensitivity Analysis

This package extends the Chapter 5.4 project with a complete Chapter 5.5 experiment workflow.

## Main scripts

Run the complete experiment:

```matlab
runChapter55AblationSensitivity
```

Run only the ablation study:

```matlab
runChapter55AblationStudy
```

Run only the sensitivity analysis:

```matlab
runChapter55SensitivityAnalysis
```


## Default run count in this one-seed version

This version sets Chapter 5.5 to one seed only:

```matlab
cfg.chapter55.seeds = 2026;
```

With the default four representative cases, the total run count is:

```text
Ablation study:      4 cases × 1 seed × 3 methods = 12 runs
TIS sensitivity:     4 cases × 1 seed × 5 values  = 20 runs
Safety sensitivity:  4 cases × 1 seed × 4 values  = 16 runs
Total:               48 runs
```


## Experiment design

### 5.5.1 Ablation study

The ablation study compares exactly three methods:

1. `TNSAOO`: full proposed method with the Thinking Innovation Strategy enabled.
2. `NSAOO`: same AOO-based optimizer but with TIS disabled.
3. `Independent`: independent baseline without upper-layer collaborative scheduling optimization.

### 5.5.2 Sensitivity analysis

This package tests two sensitivity factors:

1. TIS control parameter: `cfg.alg.tisProbability`.
   - Current default value in the code: `0.65`.
   - Tested values: `[0.35, 0.50, 0.65, 0.80, 0.95]`.

2. Air-ground safety distance: `cfg.conflict.safetyDistance`.
   - Current default value in the code: `8.0 m`.
   - Tested values: `[2, 5, 8, 10] m`.

Population size and maximum iterations are kept fixed because they are treated as computational-budget settings, not sensitivity factors in this section.

## Output files

After running, results will be saved under:

```text
results/chapter5_5_ablation_sensitivity_YYYYMMDD_HHMMSS/
```

Important CSV outputs:

```text
data/ch5_5_raw_results.csv
data/ch5_5_archive_objectives_raw.csv
data/ch5_5_archive_history_raw.csv
data/ch5_5_metrics_by_run.csv
data/ch5_5_summary_by_condition.csv
data/ch5_5_summary_by_case_condition.csv
data/ch5_5_ablation_summary.csv
data/ch5_5_sensitivity_tis_summary.csv
data/ch5_5_sensitivity_safety_summary.csv
```

Important figures:

```text
figures/figure_ch5_5_ablation_objectives.png
figures/figure_ch5_5_ablation_quality_safety.png
figures/figure_ch5_5_tis_probability_sensitivity.png
figures/figure_ch5_5_safety_distance_sensitivity.png
```

## Quick test

To run a small debug experiment, set this field in `config.m`:

```matlab
cfg.chapter55.quickTest = true;
```

For formal experiments, keep it as:

```matlab
cfg.chapter55.quickTest = false;
```
