function conditions = getChapter55Conditions(cfg)
%GETCHAPTER55CONDITIONS Define all Chapter 5.5 experimental conditions.
%
% Fixed version:
%   Avoids "Subscripted assignment between dissimilar structures" by
%   preallocating conditions using the same condition template.

methods = string(cfg.chapter55.ablationMethods);
pVals   = cfg.chapter55.tisProbabilityValues(:).';
dVals   = cfg.chapter55.safetyDistanceValues(:).';

nTotal = numel(methods) + numel(pVals) + numel(dVals);

conditions = repmat(conditionTemplate(), nTotal, 1);
k = 0;

% -------------------------------------------------------------------------
% 5.5.1 Ablation study
% -------------------------------------------------------------------------
for i = 1:numel(methods)
    method = methods(i);

    k = k + 1;
    c = conditionTemplate();

    c.experimentType = "ablation";
    c.conditionName = method;
    c.method = method;
    c.parameterName = "none";
    c.parameterValue = NaN;
    c.parameterLabel = "none";
    c.tisProbability = cfg.chapter55.baselineTisProbability;
    c.safetyDistance = cfg.chapter55.baselineSafetyDistance;

    switch upper(method)
        case "TNSAOO"
            c.runType = "optimizer";
            c.enableTIS = true;
            c.useOriginalAOOUpdate = true;
            c.description = "Full TNSAOO with TIS enabled";

        case "NSAOO"
            c.runType = "optimizer";
            c.enableTIS = false;
            c.useOriginalAOOUpdate = true;
            c.description = "NSAOO without thinking innovation strategy";

        case "INDEPENDENT"
            c.runType = "baseline";
            c.enableTIS = false;
            c.useOriginalAOOUpdate = false;
            c.description = "Independent planning baseline without upper-layer collaborative optimization";

        otherwise
            error('Unknown Chapter 5.5 ablation method: %s', method);
    end

    conditions(k) = c;
end

% -------------------------------------------------------------------------
% 5.5.2 Sensitivity: TIS probability
% -------------------------------------------------------------------------
for i = 1:numel(pVals)
    p = pVals(i);

    k = k + 1;
    c = conditionTemplate();

    c.experimentType = "sensitivity_tis";
    c.conditionName = string(sprintf('TIS_p_%.2f', p));
    c.method = "TNSAOO";
    c.runType = "optimizer";
    c.enableTIS = true;
    c.useOriginalAOOUpdate = true;
    c.parameterName = "tisProbability";
    c.parameterValue = p;
    c.parameterLabel = string(sprintf('p=%.2f', p));
    c.tisProbability = p;
    c.safetyDistance = cfg.chapter55.baselineSafetyDistance;
    c.description = string(sprintf('TNSAOO with TIS probability %.2f', p));

    conditions(k) = c;
end

% -------------------------------------------------------------------------
% 5.5.2 Sensitivity: safety distance
% -------------------------------------------------------------------------
for i = 1:numel(dVals)
    d = dVals(i);

    k = k + 1;
    c = conditionTemplate();

    c.experimentType = "sensitivity_safety";
    c.conditionName = string(sprintf('Safety_%gm', d));
    c.method = "TNSAOO";
    c.runType = "optimizer";
    c.enableTIS = true;
    c.useOriginalAOOUpdate = true;
    c.parameterName = "safetyDistance_m";
    c.parameterValue = d;
    c.parameterLabel = string(sprintf('%g m', d));
    c.tisProbability = cfg.chapter55.baselineTisProbability;
    c.safetyDistance = d;
    c.description = string(sprintf('TNSAOO with safety distance %g m', d));

    conditions(k) = c;
end

% Safety trim in case some condition list is empty.
conditions = conditions(1:k);

end


function c = conditionTemplate()
c = struct();

c.experimentType = "";
c.conditionName = "";
c.method = "";
c.runType = "";

c.parameterName = "";
c.parameterValue = NaN;
c.parameterLabel = "";

c.tisProbability = NaN;
c.safetyDistance = NaN;

c.enableTIS = false;
c.useOriginalAOOUpdate = true;

c.description = "";
end
