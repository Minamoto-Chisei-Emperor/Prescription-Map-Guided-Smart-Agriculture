function rows = addChapter55MetaToRows(rows, condition, cfg)
%ADDCHAPTER55METATOROWS Add Chapter 5.5 metadata fields to a struct array.

if isempty(rows)
    return;
end

for i = 1:numel(rows)
    rows(i).experimentType = string(condition.experimentType);
    rows(i).conditionName = string(condition.conditionName);
    rows(i).method = string(condition.method);
    rows(i).runType = string(condition.runType);
    rows(i).parameterName = string(condition.parameterName);
    rows(i).parameterValue = condition.parameterValue;
    rows(i).parameterLabel = string(condition.parameterLabel);
    rows(i).tisProbability = condition.tisProbability;
    rows(i).safetyDistance_m = condition.safetyDistance;
    rows(i).enableTIS = logical(condition.enableTIS);
    rows(i).useOriginalAOOUpdate = logical(condition.useOriginalAOOUpdate);

    rows(i).popSize = NaN;
    rows(i).maxIter = NaN;

    if isfield(cfg, 'alg')
        if isfield(cfg.alg, 'popSize')
            rows(i).popSize = cfg.alg.popSize;
        end
        if isfield(cfg.alg, 'maxIter')
            rows(i).maxIter = cfg.alg.maxIter;
        end
    end
end

end
