function plotChapter54Figures(plotData, figDir)
%PLOTCHAPTER54FIGURES Publication-style plots for Chapter 5.4.
%
% Palette intentionally differs from Chapter 5.3.

if ~exist(figDir, 'dir'), mkdir(figDir); end

pal = chapter54Palette();

plotMetricBoxFigure54(plotData.plotMetrics, figDir, pal);
plotCompromiseObjectiveFigure54(plotData.summaryAlg, figDir, pal);
plotParetoRepresentativeFigure54(plotData.plotPareto, figDir, pal);
if isfield(plotData, 'plotHVConv') && ~isempty(plotData.plotHVConv) && height(plotData.plotHVConv) > 0
    plotHVConvergenceFigure54(plotData.plotHVConv, figDir, pal);
end
end

function plotMetricBoxFigure54(T, figDir, pal)
fig = figure('Color','w','Units','centimeters','Position',[2,2,30,13]);
try
    tiledlayout(1,2,'TileSpacing','compact','Padding','compact');
    ax1 = nexttile; drawAlgorithmBox54(ax1, T, 'HV', 'Hypervolume', pal, true);
    title(ax1, '(a) Hypervolume (higher is better)', 'FontName','Times New Roman','FontSize',16,'FontWeight','bold');
    ax2 = nexttile; drawAlgorithmBox54(ax2, T, 'IGD', 'IGD', pal, false);
    title(ax2, '(b) IGD (lower is better)', 'FontName','Times New Roman','FontSize',16,'FontWeight','bold');
catch
end
try
    sgtitle('Pareto-set quality comparison of multi-objective algorithms', ...
        'FontName','Times New Roman','FontSize',20,'FontWeight','bold');
catch
end
applyChapter54FigureStyle(fig);
saveChapter54Figure(fig, figDir, 'figure_ch5_4_hv_igd_distribution');
end

function plotCompromiseObjectiveFigure54(S, figDir, pal)
algs = string(S.algorithm);
x = 1:numel(algs);

fig = figure('Color','w','Units','centimeters','Position',[2,2,32,16]);
try
    tiledlayout(2,2,'TileSpacing','compact','Padding','compact');

    ax = nexttile; drawMeanStdBar54(ax, x, S.makespan_mean, S.makespan_std, algs, pal, 'Makespan (s)');
    title(ax, '(a) Makespan', 'FontName','Times New Roman','FontSize',16,'FontWeight','bold');

    ax = nexttile; drawMeanStdBar54(ax, x, S.weightedEnergy_mean, S.weightedEnergy_std, algs, pal, 'Weighted energy');
    title(ax, '(b) Weighted energy', 'FontName','Times New Roman','FontSize',16,'FontWeight','bold');

    ax = nexttile; drawMeanStdBar54(ax, x, S.driftPenalty_mean, S.driftPenalty_std, algs, pal, 'Drift penalty');
    title(ax, '(c) Drift penalty', 'FontName','Times New Roman','FontSize',16,'FontWeight','bold');

    ax = nexttile; drawMeanStdBar54(ax, x, S.runtime_s_mean, S.runtime_s_std, algs, pal, 'Runtime (s)');
    title(ax, '(d) Runtime', 'FontName','Times New Roman','FontSize',16,'FontWeight','bold');
catch
end

try
    sgtitle('Compromise-solution performance and computational cost', ...
        'FontName','Times New Roman','FontSize',20,'FontWeight','bold');
catch
end
applyChapter54FigureStyle(fig);
saveChapter54Figure(fig, figDir, 'figure_ch5_4_compromise_objectives_runtime');
end

function plotParetoRepresentativeFigure54(T, figDir, pal)
fig = figure('Color','w','Units','centimeters','Position',[2,2,18,15]);
ax = axes(fig); hold(ax,'on');

algs = unique(string(T.algorithm), 'stable');
markers = {'o','s','^','d','p'};
for i = 1:numel(algs)
    idx = string(T.algorithm) == algs(i);
    col = algColor54(algs(i), pal);
    marker = markers{1+mod(i-1,numel(markers))};
    scatter(ax, T.normMakespan(idx), T.normEnergy(idx), 68, ...
        'Marker', marker, 'MarkerFaceColor', col, 'MarkerEdgeColor', [0.25 0.25 0.25], ...
        'MarkerFaceAlpha', 0.72, 'LineWidth', 0.7, 'DisplayName', char(algs(i)));
end

xlabel(ax, 'Normalized makespan', 'FontName','Times New Roman','FontSize',16,'FontWeight','bold');
ylabel(ax, 'Normalized weighted energy', 'FontName','Times New Roman','FontSize',16,'FontWeight','bold');
title(ax, 'Representative Pareto archive comparison', 'FontName','Times New Roman','FontSize',18,'FontWeight','bold');
grid(ax,'on'); box(ax,'on');
legend(ax, 'Location','best','Box','off','FontName','Times New Roman','FontSize',13);
applyChapter54FigureStyle(fig);
saveChapter54Figure(fig, figDir, 'figure_ch5_4_pareto_representative_case');
end

function plotHVConvergenceFigure54(T, figDir, pal)
fig = figure('Color','w','Units','centimeters','Position',[2,2,22,15]);
ax = axes(fig); hold(ax,'on');

% Average across cases for each algorithm and iteration.
algs = unique(string(T.algorithm), 'stable');
for i = 1:numel(algs)
    alg = algs(i);
    idxAlg = string(T.algorithm) == alg;
    iters = unique(T.iteration(idxAlg), 'stable');
    meanVals = nan(numel(iters),1);
    stdVals = nan(numel(iters),1);
    for k = 1:numel(iters)
        vals = T.HV_mean(idxAlg & T.iteration == iters(k));
        meanVals(k) = localMean54(vals);
        stdVals(k) = localStd54(vals);
    end
    col = algColor54(alg, pal);
    fill([iters; flipud(iters)], [meanVals-stdVals; flipud(meanVals+stdVals)], ...
        col, 'FaceAlpha', 0.12, 'EdgeColor','none', 'HandleVisibility','off');
    plot(ax, iters, meanVals, '-', 'Color', col, 'LineWidth', 2.6, 'DisplayName', char(alg));
end
xlabel(ax, 'Iteration', 'FontName','Times New Roman','FontSize',16,'FontWeight','bold');
ylabel(ax, 'Normalized hypervolume', 'FontName','Times New Roman','FontSize',16,'FontWeight','bold');
title(ax, 'Hypervolume convergence comparison', 'FontName','Times New Roman','FontSize',18,'FontWeight','bold');
grid(ax,'on'); box(ax,'on');
legend(ax, 'Location','southeast','Box','off','FontName','Times New Roman','FontSize',13);
applyChapter54FigureStyle(fig);
saveChapter54Figure(fig, figDir, 'figure_ch5_4_hv_convergence');
end

function drawAlgorithmBox54(ax, T, metricName, yLabel, pal, higherBetter)
axes(ax); hold(ax,'on'); %#ok<LAXES>
algs = string(T.algorithm);
algList = unique(algs, 'stable');
for i = 1:numel(algList)
    x = T.(metricName)(algs == algList(i));
    x = x(isfinite(x));
    if isempty(x), continue; end
    col = algColor54(algList(i), pal);
    drawOneBox54(ax, i, x, col);
end
set(ax, 'XTick',1:numel(algList), 'XTickLabel', cellstr(algList), 'XTickLabelRotation', 25);
ylabel(ax, yLabel, 'FontName','Times New Roman','FontSize',15,'FontWeight','bold');
if higherBetter
    text(ax, 0.03,0.94,'Higher is better','Units','normalized','FontName','Times New Roman','FontSize',12,'FontWeight','bold');
else
    text(ax, 0.03,0.94,'Lower is better','Units','normalized','FontName','Times New Roman','FontSize',12,'FontWeight','bold');
end
grid(ax,'on'); box(ax,'on'); hold(ax,'off');
end

function drawOneBox54(ax, xpos, x, col)
q1 = prctileLocal54(x,25); q2 = prctileLocal54(x,50); q3 = prctileLocal54(x,75);
iqrVal = q3-q1;
lo = max(min(x), q1-1.5*iqrVal);
hi = min(max(x), q3+1.5*iqrVal);
patch(ax, xpos+[-0.25 0.25 0.25 -0.25], [q1 q1 q3 q3], col, 'FaceAlpha',0.40, 'EdgeColor', col*0.72, 'LineWidth',1.5);
plot(ax, xpos+[-0.25 0.25], [q2 q2], '-', 'Color', col*0.62, 'LineWidth',2.1);
plot(ax, [xpos xpos], [lo q1], '-', 'Color', col*0.62, 'LineWidth',1.4);
plot(ax, [xpos xpos], [q3 hi], '-', 'Color', col*0.62, 'LineWidth',1.4);
plot(ax, xpos+[-0.12 0.12], [lo lo], '-', 'Color', col*0.62, 'LineWidth',1.4);
plot(ax, xpos+[-0.12 0.12], [hi hi], '-', 'Color', col*0.62, 'LineWidth',1.4);
rng(100+xpos);
jitter = 0.10*(rand(size(x))-0.5);
scatter(ax, xpos+jitter, x, 26, 'MarkerFaceColor', col, 'MarkerEdgeColor',[0.25 0.25 0.25], 'MarkerFaceAlpha',0.58, 'LineWidth',0.45);
end

function drawMeanStdBar54(ax, x, mu, sig, algs, pal, ylab)
axes(ax); hold(ax,'on'); %#ok<LAXES>
colors = zeros(numel(algs),3);
for i = 1:numel(algs), colors(i,:) = algColor54(algs(i), pal); end
b = bar(ax, x, mu, 0.72, 'FaceColor','flat', 'EdgeColor',[0.28 0.28 0.30], 'LineWidth',0.9);
b.CData = colors;
errorbar(ax, x, mu, sig, 'k.', 'LineWidth',1.3, 'CapSize',10);
set(ax, 'XTick',x, 'XTickLabel',cellstr(algs), 'XTickLabelRotation',25);
ylabel(ax, ylab, 'FontName','Times New Roman','FontSize',15,'FontWeight','bold');
grid(ax,'on'); box(ax,'on'); hold(ax,'off');
end

function q = prctileLocal54(x,p)
x = sort(x(:)); x = x(isfinite(x));
if isempty(x), q = NaN; return; end
if numel(x) == 1, q = x; return; end
pos = 1 + (p/100)*(numel(x)-1);
lo = floor(pos); hi = ceil(pos);
if lo == hi, q = x(lo); else, q = x(lo) + (pos-lo)*(x(hi)-x(lo)); end
end


function y = localMean54(x)
x = x(:);
x = x(isfinite(x));
if isempty(x), y = NaN; else, y = mean(x); end
end

function y = localStd54(x)
x = x(:);
x = x(isfinite(x));
if numel(x) <= 1, y = 0; else, y = std(x); end
end
