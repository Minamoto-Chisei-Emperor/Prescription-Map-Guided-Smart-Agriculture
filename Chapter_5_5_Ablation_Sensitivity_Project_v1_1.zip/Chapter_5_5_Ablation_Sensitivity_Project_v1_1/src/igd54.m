function val = igd54(solution, refFront)
%IGD54 Inverted generational distance.

if isempty(solution) || isempty(refFront)
    val = NaN;
    return;
end

d = zeros(size(refFront,1),1);
for i = 1:size(refFront,1)
    diff = solution - refFront(i,:);
    dist = sqrt(sum(diff.^2,2));
    d(i) = min(dist);
end
val = mean(d);
end
