function elite = selectEliteFromArchive54(archive)
%SELECTELITEFROMARCHIVE54 Select one elite from archive using crowding-biased roulette.

if isempty(archive)
    error('Archive is empty.');
end

crowd = [archive.crowding];
if isempty(crowd) || all(~isfinite(crowd)) || all(crowd == 0)
    elite = archive(randi(numel(archive)));
    return;
end

finiteCrowd = crowd(isfinite(crowd));
if isempty(finiteCrowd)
    elite = archive(randi(numel(archive)));
    return;
end

crowd(~isfinite(crowd)) = max(finiteCrowd) + 1;
crowd = max(crowd, 0);

if sum(crowd) <= 0
    elite = archive(randi(numel(archive)));
else
    prob = crowd(:) ./ sum(crowd);
    idx = find(rand() <= cumsum(prob), 1, 'first');
    if isempty(idx), idx = randi(numel(archive)); end
    elite = archive(idx);
end
end
