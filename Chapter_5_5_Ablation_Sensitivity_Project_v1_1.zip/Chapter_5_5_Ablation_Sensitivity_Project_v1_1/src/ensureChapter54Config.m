function cfg = ensureChapter54Config(cfg)
%ENSURECHAPTER54CONFIG Fill missing fields for Chapter 5.4.

if ~isfield(cfg, 'chapter54'), cfg.chapter54 = struct(); end

if ~isfield(cfg.chapter54, 'caseFiles')
    cfg.chapter54.caseFiles = {'ee_field_9.wkt','lt_field_258.wkt','nl_field_24.wkt','nl_field_54.wkt'};
end
if ~isfield(cfg.chapter54, 'caseNames')
    cfg.chapter54.caseNames = {'Case 1: Large Estonian field','Case 2: Lithuanian field','Case 3: Dutch field A','Case 4: Dutch field B'};
end
if ~isfield(cfg.chapter54, 'algorithms')
    cfg.chapter54.algorithms = {'TNSAOO','NSGAII','MOPSO','NSWOA','MOEAD'};
end
if ~isfield(cfg.chapter54, 'seeds'), cfg.chapter54.seeds = [2026,2027,2028,2029,2030]; end
if ~isfield(cfg.chapter54, 'popSize'), cfg.chapter54.popSize = 20; end
if ~isfield(cfg.chapter54, 'maxIter'), cfg.chapter54.maxIter = 20; end
if ~isfield(cfg.chapter54, 'archiveSize'), cfg.chapter54.archiveSize = 50; end
if ~isfield(cfg.chapter54, 'nSprayTasks'), cfg.chapter54.nSprayTasks = [8,6,6,6]; end
if ~isfield(cfg.chapter54, 'nFertTasks'), cfg.chapter54.nFertTasks = [8,6,6,6]; end
if ~isfield(cfg.chapter54, 'nObstacles'), cfg.chapter54.nObstacles = [3,2,2,2]; end
if ~isfield(cfg.chapter54, 'nRefillCandidates'), cfg.chapter54.nRefillCandidates = [5,4,4,4]; end
if ~isfield(cfg.chapter54, 'outputPrefix'), cfg.chapter54.outputPrefix = 'chapter5_4_algorithm_comparison'; end
if ~isfield(cfg.chapter54, 'representativeCaseIndex'), cfg.chapter54.representativeCaseIndex = 1; end
if ~isfield(cfg.chapter54, 'representativeSeed'), cfg.chapter54.representativeSeed = cfg.chapter54.seeds(1); end
if ~isfield(cfg.chapter54, 'savePerRunMat'), cfg.chapter54.savePerRunMat = false; end
if ~isfield(cfg.chapter54, 'saveWorkspace'), cfg.chapter54.saveWorkspace = true; end
if ~isfield(cfg.chapter54, 'includeKnownFieldObstacles'), cfg.chapter54.includeKnownFieldObstacles = true; end

% Important defaults needed by random-key decoding and scenario generation.
if ~isfield(cfg, 'alg'), cfg.alg = struct(); end
if ~isfield(cfg.alg, 'lb'), cfg.alg.lb = -5; end
if ~isfield(cfg.alg, 'ub'), cfg.alg.ub = 5; end
if ~isfield(cfg.alg, 'sigmoidThreshold'), cfg.alg.sigmoidThreshold = 0.50; end
if ~isfield(cfg.alg, 'minActiveRefill'), cfg.alg.minActiveRefill = 1; end
if ~isfield(cfg.alg, 'tisProbability'), cfg.alg.tisProbability = 0.65; end
if ~isfield(cfg.alg, 'useOriginalAOOUpdate'), cfg.alg.useOriginalAOOUpdate = true; end
if ~isfield(cfg.alg, 'enableTIS'), cfg.alg.enableTIS = true; end
if ~isfield(cfg.alg, 'aooStepInitial'), cfg.alg.aooStepInitial = 1.2; end
if ~isfield(cfg.alg, 'aooStepFinal'), cfg.alg.aooStepFinal = 0.15; end

if ~isfield(cfg, 'env'), cfg.env = struct(); end
if ~isfield(cfg.env, 'includeKnownFieldObstacles'), cfg.env.includeKnownFieldObstacles = cfg.chapter54.includeKnownFieldObstacles; end
end
