function ind = makeEvaluatedIndividual54(position, env, cfg)
%MAKEEVALUATEDINDIVIDUAL54 Create and evaluate one individual.

position = clampPosition(position, cfg.alg.lb, cfg.alg.ub);
ind = emptyIndividual54(numel(position));
ind.position = position;
ind.decoded = decodeSolution(position, env, cfg);
ind = evaluateSolution(ind, env, cfg);
end
