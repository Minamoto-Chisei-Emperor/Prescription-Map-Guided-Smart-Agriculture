function [archive, history] = moeadOptimizer54(env, cfg)
%MOEADOPTIMIZER54 MOEA/D baseline using Tchebycheff decomposition.

fprintf('Running MOEA/D...\n');

N = cfg.alg.popSize;
nVar = cfg.env.nSprayTasks + cfg.env.nFertTasks + cfg.env.nRefillCandidates;
lb = cfg.alg.lb; ub = cfg.alg.ub;
F = 0.5; CR = 0.9;
T = min(5, N);

weights = generateWeights54(N, 3);
D = squareformDistance54(weights);
[~, neigh] = sort(D, 2);
neigh = neigh(:,1:T);

pop = initializePopulation(env, cfg);
for i = 1:numel(pop)
    pop(i) = evaluateSolution(pop(i), env, cfg);
end

archive = updateArchive([], pop, cfg);
history = initHistory54(cfg.alg.maxIter);
ideal = min(reshape([pop.objectives], 3, []).', [], 1);

for iter = 1:cfg.alg.maxIter
    for i = 1:N
        B = neigh(i,:);
        if numel(B) < 3
            pool = 1:N;
        else
            pool = B;
        end
        ids = pool(randperm(numel(pool), min(3,numel(pool))));
        while numel(ids) < 3
            ids(end+1) = randi(N); %#ok<AGROW>
        end

        x1 = pop(ids(1)).position;
        x2 = pop(ids(2)).position;
        x3 = pop(ids(3)).position;
        mutant = x1 + F*(x2-x3);

        target = pop(i).position;
        mask = rand(1,nVar) < CR;
        if ~any(mask), mask(randi(nVar)) = true; end
        childPos = target;
        childPos(mask) = mutant(mask);
        childPos = childPos + 0.03*(ub-lb)*randn(1,nVar);

        child = makeEvaluatedIndividual54(childPos, env, cfg);
        ideal = min(ideal, child.objectives);

        for jj = 1:numel(B)
            k = B(jj);
            if tcheby54(child.objectives, weights(k,:), ideal) <= tcheby54(pop(k).objectives, weights(k,:), ideal)
                pop(k) = child;
            end
        end
    end

    archive = updateArchive(archive, pop, cfg);
    history = recordHistory54(history, archive, iter);

    fprintf('MOEA/D iter %03d/%03d | archive=%d\n', iter, cfg.alg.maxIter, numel(archive));
end
end

function W = generateWeights54(N, M)
W = rand(N,M);
W = W ./ sum(W,2);
% Add three extreme-ish weights if possible.
if N >= 3
    W(1,:) = [0.90,0.05,0.05];
    W(2,:) = [0.05,0.90,0.05];
    W(3,:) = [0.05,0.05,0.90];
end
end

function d = tcheby54(obj, w, ideal)
w = max(w, 1e-6);
d = max(w .* abs(obj - ideal));
end

function D = squareformDistance54(X)
N = size(X,1);
D = zeros(N,N);
for i = 1:N
    for j = i+1:N
        d = norm(X(i,:)-X(j,:));
        D(i,j) = d;
        D(j,i) = d;
    end
end
end
