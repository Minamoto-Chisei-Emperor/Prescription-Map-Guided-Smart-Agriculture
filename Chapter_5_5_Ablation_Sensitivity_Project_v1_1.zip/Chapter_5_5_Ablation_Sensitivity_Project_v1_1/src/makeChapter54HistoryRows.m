function rows = makeChapter54HistoryRows(runId, caseId, caseName, algName, seed, history)
%MAKECHAPTER54HISTORYROWS Store archive objective points per iteration.
%
% This version fixes:
%   "在不同结构体之间进行下标赋值"
%
% Cause:
%   rows = struct([]) has no predefined fields in some MATLAB versions.
%   Assigning a template with fields to rows(cnt,1) may fail.
%
% Fix:
%   Define the template first, then initialize rows as an empty struct array
%   with exactly the same fields:
%       rows = repmat(template, 0, 1);

template = struct( ...
    'runId', NaN, ...
    'caseId', NaN, ...
    'caseName', "", ...
    'algorithm', "", ...
    'seed', NaN, ...
    'iteration', NaN, ...
    'pointId', NaN, ...
    'makespan', NaN, ...
    'weightedEnergy', NaN, ...
    'driftPenalty', NaN);

rows = repmat(template, 0, 1);

if isempty(history)
    return;
end

if ~isstruct(history)
    return;
end

if ~isfield(history, 'archiveObjsByIter')
    return;
end

if isempty(history.archiveObjsByIter)
    return;
end

cnt = 0;

for iter = 1:numel(history.archiveObjsByIter)

    obj = history.archiveObjsByIter{iter};

    if isempty(obj)
        continue;
    end

    if ~isnumeric(obj)
        continue;
    end

    if size(obj, 2) < 3
        continue;
    end

    for p = 1:size(obj, 1)

        cnt = cnt + 1;
        rows(cnt, 1) = template; %#ok<AGROW>

        rows(cnt).runId = runId;
        rows(cnt).caseId = caseId;
        rows(cnt).caseName = string(caseName);
        rows(cnt).algorithm = string(algName);
        rows(cnt).seed = seed;

        rows(cnt).iteration = iter;
        rows(cnt).pointId = p;

        rows(cnt).makespan = obj(p, 1);
        rows(cnt).weightedEnergy = obj(p, 2);
        rows(cnt).driftPenalty = obj(p, 3);
    end
end

end
