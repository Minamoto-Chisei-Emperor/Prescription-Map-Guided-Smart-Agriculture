function [archive, history] = nsga2Optimizer54(env, cfg)
%NSGA2OPTIMIZER54 Random-key NSGA-II baseline.

fprintf('Running NSGA-II...\n');

N = cfg.alg.popSize;
nVar = cfg.env.nSprayTasks + cfg.env.nFertTasks + cfg.env.nRefillCandidates;
pc = 0.90;
pm = 1 / nVar;
eta = 0.12 * (cfg.alg.ub - cfg.alg.lb);

pop = initializePopulation(env, cfg);
for i = 1:numel(pop)
    pop(i) = evaluateSolution(pop(i), env, cfg);
end

archive = updateArchive([], pop, cfg);
history = initHistory54(cfg.alg.maxIter);

for iter = 1:cfg.alg.maxIter
    pop = assignRankCrowding54(pop);

    offspring = repmat(emptyIndividual54(nVar), N, 1);
    k = 1;
    while k <= N
        p1 = dominanceTournament54(pop);
        p2 = dominanceTournament54(pop);

        x1 = p1.position;
        x2 = p2.position;

        if rand() < pc
            alpha = rand(1,nVar);
            c1 = alpha.*x1 + (1-alpha).*x2;
            c2 = alpha.*x2 + (1-alpha).*x1;
        else
            c1 = x1; c2 = x2;
        end

        mut1 = rand(1,nVar) < pm;
        mut2 = rand(1,nVar) < pm;
        c1(mut1) = c1(mut1) + eta*randn(1,sum(mut1));
        c2(mut2) = c2(mut2) + eta*randn(1,sum(mut2));

        offspring(k) = makeEvaluatedIndividual54(c1, env, cfg);
        if k+1 <= N
            offspring(k+1) = makeEvaluatedIndividual54(c2, env, cfg);
        end
        k = k + 2;
    end

    combined = [pop(:); offspring(:)];
    pop = environmentalSelection54(combined, N);
    archive = updateArchive(archive, pop, cfg);
    history = recordHistory54(history, archive, iter);

    fprintf('NSGA-II iter %03d/%03d | archive=%d\n', iter, cfg.alg.maxIter, numel(archive));
end
end

function pop = assignRankCrowding54(pop)
fronts = nonDominatedSort(pop);
for f = 1:numel(fronts)
    idx = fronts{f};
    d = crowdingDistance(pop, idx);
    for i = 1:numel(idx)
        pop(idx(i)).rank = f;
        pop(idx(i)).crowding = d(i);
    end
end
end
