function out = appendStructArray(in, add)
%APPENDSTRUCTARRAY Robustly append struct arrays with automatic field union.
%
% This version is designed for Chapter 5.5 result saving.
% It fixes the MATLAB error:
%   "Subscripted assignment between dissimilar structures."
%
% Cause:
%   Different runs may produce structs with slightly different fields,
%   especially between successful runs, failed runs, archive rows, and
%   history rows.
%
% Strategy:
%   1. Convert both inputs to column struct arrays.
%   2. Build the union of all field names.
%   3. Add missing fields with [].
%   4. Reorder fields consistently.
%   5. Concatenate safely.

if nargin < 1 || isempty(in)
    in = struct([]);
end

if nargin < 2 || isempty(add)
    out = in;
    return;
end

in = in(:);
add = add(:);

if isempty(in)
    out = add;
    return;
end

% Field union.
fieldsIn  = fieldnames(in);
fieldsAdd = fieldnames(add);
allFields = unique([fieldsIn; fieldsAdd], 'stable');

% Standardize both sides.
in  = standardizeStructFields55(in, allFields);
add = standardizeStructFields55(add, allFields);

out = [in; add];

end


function S = standardizeStructFields55(S, allFields)
%STANDARDIZESTRUCTFIELDS55 Add missing fields and align field order.

if isempty(S)
    return;
end

currentFields = fieldnames(S);

for f = 1:numel(allFields)
    name = allFields{f};

    if ~ismember(name, currentFields)
        % Assign [] to all elements. This keeps the struct array compatible.
        for i = 1:numel(S)
            S(i).(name) = [];
        end
    end
end

% Reorder fields consistently.
S = orderfields(S, allFields);

end
