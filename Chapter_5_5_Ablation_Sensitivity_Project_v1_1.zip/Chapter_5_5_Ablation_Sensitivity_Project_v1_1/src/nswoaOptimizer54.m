function [archive, history] = nswoaOptimizer54(env, cfg)
%NSWOAOPTIMIZER54 Non-dominated sorting whale optimization algorithm baseline.

fprintf('Running NSWOA...\n');

N = cfg.alg.popSize;
nVar = cfg.env.nSprayTasks + cfg.env.nFertTasks + cfg.env.nRefillCandidates;
lb = cfg.alg.lb; ub = cfg.alg.ub;

pop = initializePopulation(env, cfg);
for i = 1:numel(pop)
    pop(i) = evaluateSolution(pop(i), env, cfg);
end

archive = updateArchive([], pop, cfg);
history = initHistory54(cfg.alg.maxIter);

for iter = 1:cfg.alg.maxIter
    a = 2 - 2*(iter-1)/max(1,cfg.alg.maxIter-1);
    newPop = pop;
    X = positionMatrix54(pop);

    for i = 1:N
        leader = selectEliteFromArchive54(archive);
        r1 = rand(); r2 = rand();
        A = 2*a*r1 - a;
        C = 2*r2;
        p = rand();
        l = -1 + 2*rand();

        if p < 0.5
            if abs(A) < 1
                D = abs(C*leader.position - pop(i).position);
                newPos = leader.position - A*D;
            else
                randIdx = randi(N);
                Xrand = X(randIdx,:);
                D = abs(C*Xrand - pop(i).position);
                newPos = Xrand - A*D;
            end
        else
            D = abs(leader.position - pop(i).position);
            b = 1.0;
            newPos = D .* exp(b*l).*cos(2*pi*l) + leader.position;
        end

        if rand() < 0.18
            newPos = newPos + 0.08*(ub-lb)*randn(1,nVar);
        end

        cand = makeEvaluatedIndividual54(newPos, env, cfg);
        if betterIndividual(cand, pop(i))
            newPop(i) = cand;
        else
            newPop(i) = pop(i);
        end
    end

    pop = environmentalSelection54([pop(:); newPop(:)], N);
    archive = updateArchive(archive, pop, cfg);
    history = recordHistory54(history, archive, iter);

    fprintf('NSWOA iter %03d/%03d | archive=%d\n', iter, cfg.alg.maxIter, numel(archive));
end
end
