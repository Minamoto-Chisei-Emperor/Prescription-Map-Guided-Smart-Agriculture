function X = positionMatrix54(pop)
%POSITIONMATRIX54 Convert population positions to matrix.

nVar = numel(pop(1).position);
X = reshape([pop.position], nVar, []).';
end
