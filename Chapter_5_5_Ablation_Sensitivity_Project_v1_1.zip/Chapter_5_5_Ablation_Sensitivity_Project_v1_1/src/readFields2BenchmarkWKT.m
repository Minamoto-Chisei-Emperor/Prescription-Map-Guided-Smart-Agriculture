function field = readFields2BenchmarkWKT(cfg)
%READFIELDS2BENCHMARKWKT Read a WKT field boundary and convert it to meters.
%
% This version is robust to both:
%   data/wkt/*.wkt
% and:
%   data/wkt/wkt/*.wkt
%
% It also searches recursively under data/wkt and data.

% -------------------------------------------------------------------------
% 1. Make sure WKT data exists or unzip wkt.zip when necessary.
% -------------------------------------------------------------------------
if ~isfield(cfg, 'paths') || ~isfield(cfg.paths, 'wktDir')
    error('cfg.paths.wktDir is missing.');
end

if ~isfield(cfg.paths, 'dataDir')
    cfg.paths.dataDir = fileparts(cfg.paths.wktDir);
end

if ~isfield(cfg.paths, 'wktZip')
    cfg.paths.wktZip = fullfile(cfg.paths.dataDir, 'wkt.zip');
end

wktFiles = listWKTFilesRecursive(cfg.paths.wktDir);

% If data/wkt has no WKT files, try data directory as well.
if isempty(wktFiles)
    wktFiles = listWKTFilesRecursive(cfg.paths.dataDir);
end

% If still empty, unzip wkt.zip and search again.
if isempty(wktFiles)
    if exist(cfg.paths.wktZip, 'file')
        fprintf('Unzipping WKT data from %s ...\n', cfg.paths.wktZip);
        unzip(cfg.paths.wktZip, cfg.paths.dataDir);

        wktFiles = listWKTFilesRecursive(cfg.paths.wktDir);

        if isempty(wktFiles)
            wktFiles = listWKTFilesRecursive(cfg.paths.dataDir);
        end
    else
        error('WKT data not found. Expected WKT files under %s or zip file %s.', ...
            cfg.paths.wktDir, cfg.paths.wktZip);
    end
end

if isempty(wktFiles)
    error('No .wkt files found recursively under %s or %s.', ...
        cfg.paths.wktDir, cfg.paths.dataDir);
end

% -------------------------------------------------------------------------
% 2. Locate requested WKT file.
% -------------------------------------------------------------------------
if ~isfield(cfg, 'data') || ~isfield(cfg.data, 'fieldFileName')
    error('cfg.data.fieldFileName is missing.');
end

requestedName = char(string(cfg.data.fieldFileName));

% If cfg.data.fieldFileName is already a full path, use it directly.
if exist(requestedName, 'file')
    wktPath = requestedName;
else
    wktPath = findWKTByName(wktFiles, requestedName);
end

% If requested file is missing, optionally auto-pick the first WKT.
if isempty(wktPath)
    if isfield(cfg.data, 'autoPickIfMissing') && cfg.data.autoPickIfMissing
        wktPath = fullfile(wktFiles(1).folder, wktFiles(1).name);
        warning('Requested field "%s" was not found. Auto-picked: %s', ...
            requestedName, wktFiles(1).name);
    else
        availableNames = string({wktFiles.name});
        previewN = min(20, numel(availableNames));
        error('Requested WKT file not found: %s\nFirst available WKT files:\n%s', ...
            requestedName, strjoin(availableNames(1:previewN), newline));
    end
end

% -------------------------------------------------------------------------
% 3. Read polygon and convert lon/lat to local metric coordinates.
% -------------------------------------------------------------------------
[lon, lat] = readWKTPolygon(wktPath);
[x, y, origin] = lonLatToLocalXY(lon, lat);

poly = polyshape(x, y, 'Simplify', true);

if area(poly) <= 0
    error('Invalid or zero-area polygon: %s', wktPath);
end

field = struct();
field.file = wktPath;

[~, name, ext] = fileparts(wktPath);
field.name = [name, ext];

field.lonlat = [lon(:), lat(:)];
field.xy = [x(:), y(:)];
field.origin = origin;
field.poly = poly;
field.area = area(poly);
field.bbox = [min(x), max(x), min(y), max(y)];
field.width = field.bbox(2) - field.bbox(1);
field.height = field.bbox(4) - field.bbox(3);

fprintf('Loaded field %s | area = %.1f m^2 | bbox = %.1f x %.1f m\n', ...
    field.name, field.area, field.width, field.height);

end


function files = listWKTFilesRecursive(rootDir)
%LISTWKTFILESRECURSIVE Recursively list .wkt files without relying on **.

files = struct('name', {}, 'folder', {}, 'date', {}, 'bytes', {}, ...
    'isdir', {}, 'datenum', {});

if isempty(rootDir) || ~exist(rootDir, 'dir')
    return;
end

directFiles = dir(fullfile(rootDir, '*.wkt'));
files = [files; directFiles(:)];

items = dir(rootDir);

for i = 1:numel(items)
    name = items(i).name;

    if items(i).isdir && ~strcmp(name, '.') && ~strcmp(name, '..')
        subDir = fullfile(rootDir, name);
        subFiles = listWKTFilesRecursive(subDir);
        files = [files; subFiles(:)]; %#ok<AGROW>
    end
end

end


function wktPath = findWKTByName(wktFiles, requestedName)
%FINDWKBYNAME Find requested WKT file by exact filename, case-insensitive.

wktPath = '';

requestedName = char(string(requestedName));
[~, reqBase, reqExt] = fileparts(requestedName);

if isempty(reqExt)
    requestedFullName = [reqBase, '.wkt'];
else
    requestedFullName = [reqBase, reqExt];
end

for i = 1:numel(wktFiles)
    if strcmpi(wktFiles(i).name, requestedFullName)
        wktPath = fullfile(wktFiles(i).folder, wktFiles(i).name);
        return;
    end
end

end
