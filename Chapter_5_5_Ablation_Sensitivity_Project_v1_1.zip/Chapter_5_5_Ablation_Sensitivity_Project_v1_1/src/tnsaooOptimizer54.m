function [archive, history] = tnsaooOptimizer54(env, cfg)
%TNSAOOOPTIMIZER54 TNSAOO with archive history for Chapter 5.4.

fprintf('Running TNSAOO...\n');

pop = initializePopulation(env, cfg);
for i = 1:numel(pop)
    pop(i) = evaluateSolution(pop(i), env, cfg);
end

archive = updateArchive([], pop, cfg);
nVar = numel(pop(1).position);
aooState = initAOOState(numel(pop), nVar);
history = initHistory54(cfg.alg.maxIter);

for iter = 1:cfg.alg.maxIter
    popPositions = positionMatrix54(pop);
    newPop = pop;

    for i = 1:numel(pop)
        elite = selectEliteFromArchive54(archive);
        aooState.index = i;

        if isfield(cfg.alg, 'useOriginalAOOUpdate') && cfg.alg.useOriginalAOOUpdate
            candidatePos = aooUpdateCandidate(pop(i).position, elite.position, popPositions, aooState, ...
                iter, cfg.alg.maxIter, cfg.alg.lb, cfg.alg.ub);
        else
            step = cfg.alg.aooStepInitial + ...
                (cfg.alg.aooStepFinal-cfg.alg.aooStepInitial)*(iter-1)/max(1,cfg.alg.maxIter-1);
            center = mean(popPositions, 1);
            candidatePos = pop(i).position + step*randn(1,nVar) + ...
                0.45*step*rand(1,nVar).*(elite.position-pop(i).position) + ...
                0.25*step*rand(1,nVar).*(pop(i).position-center);
        end

        if ~isfield(cfg.alg, 'enableTIS') || cfg.alg.enableTIS
            if rand() < cfg.alg.tisProbability
                candidatePos = thinkingInnovation(candidatePos, archive, iter, cfg.alg.maxIter, cfg);
            end
        end

        cand = makeEvaluatedIndividual54(candidatePos, env, cfg);
        if betterIndividual(cand, pop(i))
            newPop(i) = cand;
        end
    end

    pop = newPop;
    archive = updateArchive(archive, pop, cfg);
    history = recordHistory54(history, archive, iter);

    fprintf('TNSAOO iter %03d/%03d | archive=%d\n', iter, cfg.alg.maxIter, numel(archive));
end
end
