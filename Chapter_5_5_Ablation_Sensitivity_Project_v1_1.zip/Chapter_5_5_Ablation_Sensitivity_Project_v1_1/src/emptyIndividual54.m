function ind = emptyIndividual54(nVar)
%EMPTYINDIVIDUAL54 Create an empty individual.

ind = struct();
ind.position = zeros(1,nVar);
ind.decoded = [];
ind.objectives = [Inf, Inf, Inf];
ind.violation = Inf;
ind.metrics = struct();
ind.details = struct();
ind.rank = Inf;
ind.crowding = 0;
end
