function row = makeChapter55RunRecord(runId, caseId, caseName, condition, seed, env, best, archive, history, cfg, runtime, geo, status, errorMessage)
%MAKECHAPTER55RUNRECORD One raw result row for Chapter 5.5.

row = makeChapter54RunRecord(runId, caseId, caseName, condition.conditionName, seed, env, best, archive, history, cfg, runtime, geo, status, errorMessage);
row = addChapter55Meta(row, condition, cfg);
end
