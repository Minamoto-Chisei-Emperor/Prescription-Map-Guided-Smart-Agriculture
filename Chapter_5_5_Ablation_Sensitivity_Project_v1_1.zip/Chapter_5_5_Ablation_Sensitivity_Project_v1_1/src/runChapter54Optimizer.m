function [archive, history] = runChapter54Optimizer(algName, env, cfg)
%RUNCHAPTER54OPTIMIZER Dispatch Chapter 5.4 optimizers.

alg = upper(string(algName));
switch alg
    case "TNSAOO"
        [archive, history] = tnsaooOptimizer54(env, cfg);
    case "NSGAII"
        [archive, history] = nsga2Optimizer54(env, cfg);
    case "MOPSO"
        [archive, history] = mopsoOptimizer54(env, cfg);
    case "NSWOA"
        [archive, history] = nswoaOptimizer54(env, cfg);
    case "MOEAD"
        [archive, history] = moeadOptimizer54(env, cfg);
    otherwise
        error('Unknown Chapter 5.4 algorithm: %s', algName);
end
end
