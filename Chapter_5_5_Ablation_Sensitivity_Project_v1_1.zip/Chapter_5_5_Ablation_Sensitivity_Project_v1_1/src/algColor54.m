function col = algColor54(alg, pal)
%ALGCOLOR54 Return color for an algorithm.

a = upper(string(alg));
switch a
    case "TNSAOO"
        col = pal.tnsaoo;
    case "NSGAII"
        col = pal.nsgaii;
    case "MOPSO"
        col = pal.mopso;
    case "NSWOA"
        col = pal.nswoa;
    case "MOEAD"
        col = pal.moead;
    otherwise
        col = pal.gray;
end
end
