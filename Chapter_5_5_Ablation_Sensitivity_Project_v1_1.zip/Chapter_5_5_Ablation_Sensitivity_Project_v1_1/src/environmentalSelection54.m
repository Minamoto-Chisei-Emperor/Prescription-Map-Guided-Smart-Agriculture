function selected = environmentalSelection54(pop, N)
%ENVIRONMENTALSELECTION54 NSGA-II-style environmental selection.

if numel(pop) <= N
    selected = pop;
    return;
end

fronts = nonDominatedSort(pop);
selected = pop([]);

for f = 1:numel(fronts)
    idx = fronts{f};
    if isempty(idx), continue; end

    d = crowdingDistance(pop, idx);
    for k = 1:numel(idx)
        pop(idx(k)).rank = f;
        pop(idx(k)).crowding = d(k);
    end

    if numel(selected) + numel(idx) <= N
        selected = [selected; pop(idx)]; %#ok<AGROW>
    else
        [~, order] = sort(d, 'descend');
        remain = N - numel(selected);
        selected = [selected; pop(idx(order(1:remain)))]; %#ok<AGROW>
        break;
    end
end
end
