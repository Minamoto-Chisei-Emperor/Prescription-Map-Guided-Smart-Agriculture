function row = makeChapter54RunRecord(runId, caseId, caseName, algName, seed, env, best, archive, history, cfg, runtime, geo, status, errorMessage)
%MAKECHAPTER54RUNRECORD One raw result row for Chapter 5.4.

row = chapter54RunTemplate();

row.runId = runId;
row.caseId = caseId;
row.caseName = string(caseName);
row.algorithm = string(algName);
row.seed = seed;
row.status = string(status);
row.errorMessage = string(errorMessage);

row.fieldName = string(env.field.name);
row.country = string(lower(env.field.name(1:min(2,numel(env.field.name)))));
row.area_m2 = env.field.area;
row.area_ha = env.field.area / 10000;
row.width_m = env.field.width;
row.height_m = env.field.height;

shape = computeFieldShapeMetricsFromPoly(env.field.poly, env.field.xy);
row.shapeIndex = shape.shapeIndex;
row.compactness = shape.compactness;
row.aspectRatio = shape.aspectRatio;

row.nSprayTasks = numel(env.sprayTasks);
row.nFertTasks = numel(env.fertTasks);
row.nObstacles = numel(env.obstacles);
row.nRefillCandidates = numel(env.refillStations);
row.activeRefillCount = numel(best.decoded.activeRefillIds);

row.popSize = cfg.alg.popSize;
row.maxIter = cfg.alg.maxIter;
row.archiveSize = numel(archive);
row.runtime_s = runtime;

row.makespan = best.objectives(1);
row.weightedEnergy = best.objectives(2);
row.driftPenalty = best.objectives(3);
row.violation = best.violation;

m = best.metrics;
row.uavPathLength = safeMetric(m, 'uavPathLength');
row.ugvPathLength = safeMetric(m, 'ugvPathLength');
row.totalPathLength = safeMetric(m, 'totalPathLength');
row.uavEnergy = safeMetric(m, 'uavEnergy');
row.ugvEnergy = safeMetric(m, 'ugvEnergy');
row.totalEnergy = safeMetric(m, 'totalEnergy');
row.conflictCount = safeMetric(m, 'conflictCount');
row.totalWaitingTime = safeMetric(m, 'totalWaitingTime');
row.sprayingCoverageRate = safeMetric(m, 'sprayingCoverageRate');
row.fertilizationCoverageRate = safeMetric(m, 'fertilizationCoverageRate');

if nargin >= 12 && ~isempty(geo)
    row.geometryValid = logical(geo.isValid);
    row.sprayObstacleOverlap = geo.sprayObstacleOverlap;
    row.fertObstacleOverlap = geo.fertObstacleOverlap;
    row.spraySameTypeOverlap = geo.spraySameTypeOverlap;
    row.fertSameTypeOverlap = geo.fertSameTypeOverlap;
end

if ~isempty(history)
    row.finalArchiveSize = row.archiveSize;
    row.finalBestMakespan = lastFinite(history.bestMakespan);
    row.finalBestEnergy = lastFinite(history.bestEnergy);
    row.finalBestDrift = lastFinite(history.bestDrift);
end
end

function row = chapter54RunTemplate()
row = struct();
row.runId = NaN;
row.caseId = NaN;
row.caseName = "";
row.algorithm = "";
row.seed = NaN;
row.status = "";
row.errorMessage = "";

row.fieldName = "";
row.country = "";
row.area_m2 = NaN;
row.area_ha = NaN;
row.width_m = NaN;
row.height_m = NaN;
row.shapeIndex = NaN;
row.compactness = NaN;
row.aspectRatio = NaN;

row.nSprayTasks = NaN;
row.nFertTasks = NaN;
row.nObstacles = NaN;
row.nRefillCandidates = NaN;
row.activeRefillCount = NaN;

row.popSize = NaN;
row.maxIter = NaN;
row.archiveSize = NaN;
row.runtime_s = NaN;

row.makespan = NaN;
row.weightedEnergy = NaN;
row.driftPenalty = NaN;
row.violation = NaN;

row.uavPathLength = NaN;
row.ugvPathLength = NaN;
row.totalPathLength = NaN;
row.uavEnergy = NaN;
row.ugvEnergy = NaN;
row.totalEnergy = NaN;
row.conflictCount = NaN;
row.totalWaitingTime = NaN;
row.sprayingCoverageRate = NaN;
row.fertilizationCoverageRate = NaN;

row.geometryValid = false;
row.sprayObstacleOverlap = NaN;
row.fertObstacleOverlap = NaN;
row.spraySameTypeOverlap = NaN;
row.fertSameTypeOverlap = NaN;

row.finalArchiveSize = NaN;
row.finalBestMakespan = NaN;
row.finalBestEnergy = NaN;
row.finalBestDrift = NaN;
end

function val = safeMetric(m, name)
if isfield(m, name)
    val = m.(name);
else
    val = NaN;
end
end

function val = lastFinite(x)
x = x(:);
x = x(isfinite(x));
if isempty(x)
    val = NaN;
else
    val = x(end);
end
end
