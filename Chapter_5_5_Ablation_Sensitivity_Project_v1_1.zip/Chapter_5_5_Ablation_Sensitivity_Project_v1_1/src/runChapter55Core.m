function [Traw, Tarchive, Thistory] = runChapter55Core(cfgBase, conditions, outDir)
%RUNCHAPTER55CORE Execute Chapter 5.5 experimental conditions.

caseFiles = cfgBase.chapter55.caseFiles;
caseNames = cfgBase.chapter55.caseNames;
seeds = cfgBase.chapter55.seeds(:).';

if numel(caseNames) ~= numel(caseFiles)
    error('chapter55.caseNames and chapter55.caseFiles must have the same length.');
end

fprintf('\n--- Chapter 5.5 core experiment ---\n');
fprintf('Cases=%d | Seeds=%d | Conditions=%d | Total runs=%d\n', ...
    numel(caseFiles), numel(seeds), numel(conditions), numel(caseFiles)*numel(seeds)*numel(conditions));

matDir = fullfile(outDir, 'mat');
dataDir = fullfile(outDir, 'data');
if ~exist(matDir, 'dir'), mkdir(matDir); end
if ~exist(dataDir, 'dir'), mkdir(dataDir); end

runRows = struct([]);
archiveRows = struct([]);
historyRows = struct([]);
runCounter = 0;

rawCsv = fullfile(dataDir, 'ch5_5_raw_results.csv');
archiveCsv = fullfile(dataDir, 'ch5_5_archive_objectives_raw.csv');
historyCsv = fullfile(dataDir, 'ch5_5_archive_history_raw.csv');

totalRuns = numel(caseFiles) * numel(seeds) * numel(conditions);

for c = 1:numel(caseFiles)
    for s = 1:numel(seeds)
        scenarioCfg = cfgBase;
        scenarioCfg.data.fieldFileName = caseFiles{c};
        scenarioCfg.seed = seeds(s);
        scenarioCfg.env.nSprayTasks = cfgBase.chapter55.nSprayTasks(c);
        scenarioCfg.env.nFertTasks = cfgBase.chapter55.nFertTasks(c);
        scenarioCfg.env.nObstacles = cfgBase.chapter55.nObstacles(c);
        scenarioCfg.env.nRefillCandidates = cfgBase.chapter55.nRefillCandidates(c);
        scenarioCfg.env.includeKnownFieldObstacles = cfgBase.chapter55.includeKnownFieldObstacles;

        rng(seeds(s) + 1000*c, 'twister');
        fprintf('\n=== Scenario: Case %d | %s | seed=%d ===\n', c, caseFiles{c}, seeds(s));

        try
            env = generateEnvironment(scenarioCfg);
        catch MEenv
            warning('Environment generation failed: Case %d seed %d: %s', c, seeds(s), MEenv.message);
            for k = 1:numel(conditions)
                runCounter = runCounter + 1;
                condition = conditions(k);
                cfgFail = applyChapter55Condition(scenarioCfg, condition);
                row = makeChapter55FailedRecord(runCounter, c, caseNames{c}, condition, seeds(s), cfgFail, MEenv);
                runRows = appendStructArray(runRows, row); %#ok<AGROW>
            end
            continue;
        end

        if cfgBase.chapter55.savePerRunMat
            save(fullfile(matDir, sprintf('env_case_%02d_seed_%d.mat', c, seeds(s))), 'env', 'scenarioCfg');
        end

        for k = 1:numel(conditions)
            runCounter = runCounter + 1;
            condition = conditions(k);
            cfgRun = applyChapter55Condition(scenarioCfg, condition);

            % Method-specific seed for optimizer randomness while keeping the
            % generated scenario identical across conditions.
            rng(seeds(s) + 1000*c + 131*k, 'twister');

            fprintf('\n[%d/%d] %s | Case=%d | seed=%d | method=%s | %s=%s\n', ...
                runCounter, totalRuns, string(condition.experimentType), c, seeds(s), ...
                string(condition.method), string(condition.parameterName), string(condition.parameterLabel));

            try
                ticRun = tic;
                if string(condition.runType) == "baseline"
                    [best, archive, history] = runIndependentPlanningBaseline(env, cfgRun);
                else
                    [archive, history] = tnsaooOptimizer54(env, cfgRun);
                    best = selectCompromiseSolution(archive);
                end
                runtime = toc(ticRun);
                geo = validateScenarioGeometry(env, cfgRun);

                row = makeChapter55RunRecord(runCounter, c, caseNames{c}, condition, seeds(s), env, best, archive, history, cfgRun, runtime, geo, 'ok', '');

                newArc = makeChapter54ArchiveRows(runCounter, c, caseNames{c}, condition.conditionName, seeds(s), archive);
                newArc = addChapter55MetaToRows(newArc, condition, cfgRun);
                if ~isempty(newArc)
                    archiveRows = appendStructArray(archiveRows, newArc); %#ok<AGROW>
                end

                newHist = makeChapter54HistoryRows(runCounter, c, caseNames{c}, condition.conditionName, seeds(s), history);
                newHist = addChapter55MetaToRows(newHist, condition, cfgRun);
                if ~isempty(newHist)
                    historyRows = appendStructArray(historyRows, newHist); %#ok<AGROW>
                end

                fprintf('OK | archive=%d | T=%.2f E=%.2f D=%.2f | conflicts=%.0f | safety=%.1fm | runtime=%.2fs\n', ...
                    numel(archive), row.makespan, row.weightedEnergy, row.driftPenalty, row.conflictCount, row.safetyDistance_m, runtime);

                if cfgBase.chapter55.savePerRunMat
                    save(fullfile(matDir, sprintf('run_%03d_case_%02d_%s_seed_%d.mat', runCounter, c, char(condition.conditionName), seeds(s))), ...
                        'cfgRun', 'env', 'archive', 'history', 'best', 'row', 'condition');
                end

            catch ME
                runtime = NaN; %#ok<NASGU>
                row = makeChapter55FailedRecord(runCounter, c, caseNames{c}, condition, seeds(s), cfgRun, ME);
                fprintf('FAILED | %s\n', ME.message);

                fid = fopen(fullfile(outDir, sprintf('error_run_%03d.txt', runCounter)), 'w');
                if fid > 0
                    fprintf(fid, '%s\n', safeGetReport(ME));
                    fclose(fid);
                end
            end

            runRows = appendStructArray(runRows, row); %#ok<AGROW>

            % Incremental saving.
            writetable(struct2table(runRows, 'AsArray', true), rawCsv);
            if ~isempty(archiveRows)
                writetable(struct2table(archiveRows, 'AsArray', true), archiveCsv);
            end
            if ~isempty(historyRows)
                writetable(struct2table(historyRows, 'AsArray', true), historyCsv);
            end
        end
    end
end

Traw = struct2table(runRows, 'AsArray', true);
if isempty(archiveRows)
    Tarchive = table();
else
    Tarchive = struct2table(archiveRows, 'AsArray', true);
end
if isempty(historyRows)
    Thistory = table();
else
    Thistory = struct2table(historyRows, 'AsArray', true);
end
end
