function row = makeChapter55FailedRecord(runId, caseId, caseName, condition, seed, cfg, ME)
%MAKECHAPTER55FAILEDRECORD Failed Chapter 5.5 result row.

row = makeChapter54FailedRecord(runId, caseId, caseName, condition.conditionName, seed, cfg, ME);
row = addChapter55Meta(row, condition, cfg);
end
