function row = makeChapter54FailedRecord(runId, caseId, caseName, algName, seed, cfg, ME)
%MAKECHAPTER54FAILEDRECORD Failed run row.

row = makeChapter54RunRecord(runId, caseId, caseName, algName, seed, ...
    failedEnv54(cfg), failedBest54(), [], [], cfg, NaN, [], 'failed', ME.message);
end

function env = failedEnv54(cfg)
env = struct();
env.field = struct();
env.field.name = cfg.data.fieldFileName;
env.field.area = NaN;
env.field.width = NaN;
env.field.height = NaN;
env.field.poly = polyshape();
env.field.xy = [NaN NaN];
env.sprayTasks = [];
env.fertTasks = [];
env.obstacles = [];
env.refillStations = [];
end

function best = failedBest54()
best = struct();
best.objectives = [NaN NaN NaN];
best.violation = NaN;
best.metrics = struct();
best.decoded = struct('activeRefillIds', []);
end
