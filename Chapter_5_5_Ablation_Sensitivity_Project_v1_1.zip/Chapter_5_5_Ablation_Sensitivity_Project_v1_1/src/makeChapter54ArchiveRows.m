function rows = makeChapter54ArchiveRows(runId, caseId, caseName, algName, seed, archive)
%MAKECHAPTER54ARCHIVEROWS Store final archive objective rows.

if isempty(archive)
    rows = struct([]);
    return;
end

rows = repmat(struct('runId',NaN,'caseId',NaN,'caseName',"",'algorithm',"",'seed',NaN, ...
    'pointId',NaN,'makespan',NaN,'weightedEnergy',NaN,'driftPenalty',NaN,'violation',NaN), numel(archive), 1);

for i = 1:numel(archive)
    rows(i).runId = runId;
    rows(i).caseId = caseId;
    rows(i).caseName = string(caseName);
    rows(i).algorithm = string(algName);
    rows(i).seed = seed;
    rows(i).pointId = i;
    rows(i).makespan = archive(i).objectives(1);
    rows(i).weightedEnergy = archive(i).objectives(2);
    rows(i).driftPenalty = archive(i).objectives(3);
    rows(i).violation = archive(i).violation;
end
end
