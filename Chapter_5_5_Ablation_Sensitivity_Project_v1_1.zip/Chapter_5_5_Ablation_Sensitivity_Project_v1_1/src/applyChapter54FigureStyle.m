function applyChapter54FigureStyle(fig)
%APPLYCHAPTER54FIGURESTYLE Times New Roman, large and clean.

if nargin < 1 || isempty(fig), fig = gcf; end
set(findall(fig,'-property','FontName'), 'FontName', 'Times New Roman');
axesObjs = findall(fig,'Type','axes');
for i = 1:numel(axesObjs)
    set(axesObjs(i), 'FontName','Times New Roman', 'FontSize',13, ...
        'LineWidth',1.15, 'TickDir','out', 'Layer','top', ...
        'GridAlpha',0.18, 'MinorGridAlpha',0.10);
end
end
