function plotChapter55SensitivityFiguresV2(resultDir)
% plotChapter55SensitivityFiguresV2
% Re-draw Chapter 5.5 sensitivity figures as 2-by-3 publication-style panels.
%
% Figures:
%   1) Sensitivity to TIS probability:
%      Row 1: HV, IGD, archive size
%      Row 2: makespan, weighted energy, drift penalty
%
%   2) Sensitivity to air-ground safety distance:
%      Row 1: conflict count, waiting time, total path length
%      Row 2: makespan, weighted energy, drift penalty
%
% Usage:
%   plotChapter55SensitivityFiguresV2
%   plotChapter55SensitivityFiguresV2('D:\...\results\chapter5_5_ablation_sensitivity_xxxxx')
%
% Required input files:
%   data/ch5_5_sensitivity_tis_summary.csv
%   data/ch5_5_sensitivity_safety_summary.csv
%
% Outputs:
%   figures_v2/figure_ch5_5_tis_probability_sensitivity_v2.png/.pdf/.fig
%   figures_v2/figure_ch5_5_safety_distance_sensitivity_v2.png/.pdf/.fig

clc;

if nargin < 1 || isempty(resultDir)
    resultDir = pwd;
end

[resultDir, dataDir] = resolveChapter55Dirs(resultDir);

figDir = fullfile(resultDir, 'figures_v2');
if ~exist(figDir, 'dir')
    mkdir(figDir);
end

tisFile = fullfile(dataDir, 'ch5_5_sensitivity_tis_summary.csv');
safeFile = fullfile(dataDir, 'ch5_5_sensitivity_safety_summary.csv');

if ~isfile(tisFile)
    error('Cannot find: %s', tisFile);
end

if ~isfile(safeFile)
    error('Cannot find: %s', safeFile);
end

Ttis = readtable(tisFile);
Tsafe = readtable(safeFile);

Ttis = sortrows(Ttis, 'parameterValue');
Tsafe = sortrows(Tsafe, 'parameterValue');

% Force Times New Roman.
set(groot, 'defaultAxesFontName', 'Times New Roman');
set(groot, 'defaultTextFontName', 'Times New Roman');
set(groot, 'defaultLegendFontName', 'Times New Roman');

% Scientific colors consistent with earlier figures.
tisLineColor  = [0.14 0.38 0.58];
tisFaceColor  = [0.58 0.75 0.88];

safeLineColor = [0.66 0.33 0.12];
safeFaceColor = [0.94 0.70 0.52];

% -------------------------------------------------------------------------
% Figure 1: TIS probability sensitivity
% -------------------------------------------------------------------------
tisSpecs = makeEmptySpecArray(6);

tisSpecs(1) = makeMetricSpec('HV',             'HV',     'HV',        false);
tisSpecs(2) = makeMetricSpec('IGD',            'IGD',             'IGD',                false);
tisSpecs(3) = makeMetricSpec('archiveSize',    'Archive size',    'Archive size',       true);
tisSpecs(4) = makeMetricSpec('makespan',       'Makespan / s',    'Makespan / s',       false);
tisSpecs(5) = makeMetricSpec('weightedEnergy', 'Weighted energy', 'Weighted energy',    false);
tisSpecs(6) = makeMetricSpec('driftPenalty',   'Drift penalty',   'Drift penalty',      false);

plotSensitivityPanel55( ...
    Ttis, ...
    'parameterValue', ...
    'TIS probability', ...
    'Sensitivity to TIS probability', ...
    tisSpecs, ...
    tisLineColor, ...
    tisFaceColor, ...
    fullfile(figDir, 'figure_ch5_5_tis_probability_sensitivity_v2'));

% -------------------------------------------------------------------------
% Figure 2: Safety distance sensitivity
% -------------------------------------------------------------------------
safeSpecs = makeEmptySpecArray(6);

safeSpecs(1) = makeMetricSpec('conflictCount',     'Conflict count',       'Conflict count',        true);
safeSpecs(2) = makeMetricSpec('totalWaitingTime',  'Waiting time / s',     'Waiting time / s',      true);
safeSpecs(3) = makeMetricSpec('totalPathLength',   'Total path length / m','Total path length / m', false);
safeSpecs(4) = makeMetricSpec('makespan',          'Makespan / s',         'Makespan / s',          false);
safeSpecs(5) = makeMetricSpec('weightedEnergy',    'Weighted energy',      'Weighted energy',       false);
safeSpecs(6) = makeMetricSpec('driftPenalty',      'Drift penalty',        'Drift penalty',         false);

plotSensitivityPanel55( ...
    Tsafe, ...
    'parameterValue', ...
    'Safety distance / m', ...
    'Sensitivity to air-ground safety distance', ...
    safeSpecs, ...
    safeLineColor, ...
    safeFaceColor, ...
    fullfile(figDir, 'figure_ch5_5_safety_distance_sensitivity_v2'));

fprintf('\nDONE. New figures are saved in:\n%s\n', figDir);

end


function plotSensitivityPanel55(T, xVar, xLabelText, mainTitleText, specs, lineColor, faceColor, outBase)

x = T.(xVar);

fig = figure( ...
    'Color', 'w', ...
    'Units', 'pixels', ...
    'Position', [80 60 1650 900]);

tl = tiledlayout(fig, 2, 3, ...
    'TileSpacing', 'compact', ...
    'Padding', 'compact');

sgtitle(tl, mainTitleText, ...
    'FontName', 'Times New Roman', ...
    'FontSize', 18, ...
    'FontWeight', 'normal');

for i = 1:6
    ax = nexttile(tl);

    meanCol = [specs(i).metric '_mean'];
    stdCol  = [specs(i).metric '_std'];

    if ~ismember(meanCol, T.Properties.VariableNames)
        error('Missing column: %s', meanCol);
    end

    y = T.(meanCol);

    if ismember(stdCol, T.Properties.VariableNames)
        e = T.(stdCol);
    else
        e = zeros(size(y));
    end

    errorbar(ax, x, y, e, ...
        '-o', ...
        'Color', lineColor, ...
        'MarkerFaceColor', faceColor, ...
        'MarkerEdgeColor', lineColor, ...
        'LineWidth', 1.55, ...
        'MarkerSize', 6.8, ...
        'CapSize', 8);

    grid(ax, 'on');
    box(ax, 'on');

    ax.FontName = 'Times New Roman';
    ax.FontSize = 11.5;
    ax.LineWidth = 0.85;
    ax.GridAlpha = 0.18;
    ax.TickDir = 'out';
    ax.XGrid = 'on';
    ax.YGrid = 'on';

    title(ax, specs(i).title, ...
        'FontName', 'Times New Roman', ...
        'FontSize', 13.5, ...
        'FontWeight', 'normal');

    ylabel(ax, specs(i).ylabel, ...
        'FontName', 'Times New Roman', ...
        'FontSize', 12.3);

    if i > 3
        xlabel(ax, xLabelText, ...
            'FontName', 'Times New Roman', ...
            'FontSize', 12.3);
    else
        xlabel(ax, '');
    end

    ax.XTick = x;

    if max(abs(x - round(x))) < 1e-12
        ax.XTickLabel = compose('%.0f', x);
    else
        ax.XTickLabel = compose('%.2f', x);
    end

    setNiceYLim55(ax, y, e, specs(i).forceZero);

    ax.LooseInset = max(ax.TightInset, 0.02);
end

set(findall(fig, '-property', 'FontName'), 'FontName', 'Times New Roman');

exportgraphics(fig, [outBase '.png'], ...
    'Resolution', 300);

exportgraphics(fig, [outBase '.pdf'], ...
    'ContentType', 'vector');

savefig(fig, [outBase '.fig']);

close(fig);

end


function setNiceYLim55(ax, y, e, forceZero)

y = y(:);
e = e(:);

valid = isfinite(y) & isfinite(e);
if ~any(valid)
    return;
end

lowVals = y(valid) - e(valid);
upVals  = y(valid) + e(valid);

yMin = min(lowVals);
yMax = max(upVals);

if ~isfinite(yMin) || ~isfinite(yMax)
    return;
end

if abs(yMax - yMin) < 1e-12
    pad = max(1, abs(yMax) * 0.15);
else
    pad = 0.10 * (yMax - yMin);
end

if forceZero
    lower = 0;
else
    lower = max(0, yMin - pad);
end

upper = yMax + pad;

if upper <= lower
    upper = lower + 1;
end

ylim(ax, [lower, upper]);

end


function specs = makeEmptySpecArray(n)

template = struct( ...
    'metric', '', ...
    'title', '', ...
    'ylabel', '', ...
    'forceZero', false);

specs = repmat(template, n, 1);

end


function s = makeMetricSpec(metric, titleText, ylabelText, forceZero)

s = struct();
s.metric = metric;
s.title = titleText;
s.ylabel = ylabelText;
s.forceZero = forceZero;

end


function [resultDir, dataDir] = resolveChapter55Dirs(inputDir)

% Case 1: user directly gives the result folder.
if isfolder(fullfile(inputDir, 'data')) && ...
        isfile(fullfile(inputDir, 'data', 'ch5_5_sensitivity_tis_summary.csv'))
    resultDir = inputDir;
    dataDir = fullfile(inputDir, 'data');
    return;
end

% Case 2: user gives the data folder.
if isfile(fullfile(inputDir, 'ch5_5_sensitivity_tis_summary.csv')) && ...
        isfile(fullfile(inputDir, 'ch5_5_sensitivity_safety_summary.csv'))
    dataDir = inputDir;
    resultDir = fileparts(inputDir);
    return;
end

% Case 3: user runs from project root; find the latest Chapter 5.5 result.
candidateRoot = fullfile(inputDir, 'results');
if isfolder(candidateRoot)
    d = dir(fullfile(candidateRoot, 'chapter5_5*'));
    d = d([d.isdir]);

    if ~isempty(d)
        [~, idx] = max([d.datenum]);
        resultDir = fullfile(candidateRoot, d(idx).name);
        dataDir = fullfile(resultDir, 'data');

        if isfile(fullfile(dataDir, 'ch5_5_sensitivity_tis_summary.csv')) && ...
                isfile(fullfile(dataDir, 'ch5_5_sensitivity_safety_summary.csv'))
            return;
        end
    end
end

error(['Cannot locate Chapter 5.5 result data. Please run this function from ', ...
       'the project root, the result folder, or the data folder.']);

end
