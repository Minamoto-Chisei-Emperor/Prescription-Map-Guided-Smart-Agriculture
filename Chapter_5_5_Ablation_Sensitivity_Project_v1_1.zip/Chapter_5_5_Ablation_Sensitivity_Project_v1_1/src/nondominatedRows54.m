function nd = nondominatedRows54(obj)
%NONDOMINATEDROWS54 Return nondominated objective rows for minimization.

if isempty(obj)
    nd = obj;
    return;
end

obj = unique(obj, 'rows', 'stable');
N = size(obj,1);
keep = true(N,1);

for i = 1:N
    if ~keep(i), continue; end
    for j = 1:N
        if i == j, continue; end
        if all(obj(j,:) <= obj(i,:) + 1e-12) && any(obj(j,:) < obj(i,:) - 1e-12)
            keep(i) = false;
            break;
        end
    end
end
nd = obj(keep,:);
end
