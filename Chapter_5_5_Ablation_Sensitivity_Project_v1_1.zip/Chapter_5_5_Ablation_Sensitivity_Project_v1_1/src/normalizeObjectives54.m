function objN = normalizeObjectives54(obj, mins, maxs)
%NORMALIZEOBJECTIVES54 Min-max normalize objective matrix.

if isempty(obj)
    objN = zeros(0,3);
    return;
end
span = maxs - mins;
span(span < 1e-12) = 1;
objN = (obj - mins) ./ span;
objN = max(min(objN, 1.5), -0.5);
end
