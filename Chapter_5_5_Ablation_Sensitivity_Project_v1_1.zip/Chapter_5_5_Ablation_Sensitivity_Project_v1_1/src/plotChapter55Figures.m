function plotChapter55Figures(plotData, figDir)
%PLOTCHAPTER55FIGURES Generate Chapter 5.5 figures.

if ~exist(figDir, 'dir'), mkdir(figDir); end

set(groot, 'defaultAxesFontName', 'Times New Roman');
set(groot, 'defaultTextFontName', 'Times New Roman');
set(groot, 'defaultLegendFontName', 'Times New Roman');

colors = chapter55Colors();

if isfield(plotData, 'ablation') && ~isempty(plotData.ablation) && height(plotData.ablation) > 0
    plotAblationObjectives55(plotData.ablation, figDir, colors);
    plotAblationQuality55(plotData.ablation, figDir, colors);
end

if isfield(plotData, 'tisSensitivity') && ~isempty(plotData.tisSensitivity) && height(plotData.tisSensitivity) > 0
    plotTISSensitivity55(plotData.tisSensitivity, figDir, colors);
end

if isfield(plotData, 'safetySensitivity') && ~isempty(plotData.safetySensitivity) && height(plotData.safetySensitivity) > 0
    plotSafetySensitivity55(plotData.safetySensitivity, figDir, colors);
end
end

function colors = chapter55Colors()
colors = struct();
colors.softBlue = [0.58 0.75 0.88];
colors.deepBlue = [0.14 0.38 0.58];
colors.softOrange = [0.94 0.70 0.52];
colors.deepOrange = [0.66 0.33 0.12];
colors.softGreen = [0.64 0.80 0.62];
colors.deepGreen = [0.25 0.50 0.25];
colors.softPurple = [0.74 0.66 0.84];
colors.deepPurple = [0.42 0.31 0.58];
colors.gray = [0.55 0.55 0.55];
colors.darkGray = [0.20 0.20 0.20];
colors.fills = [colors.softBlue; colors.softOrange; colors.softGreen; colors.softPurple; 0.62 0.80 0.79];
colors.edges = [colors.deepBlue; colors.deepOrange; colors.deepGreen; colors.deepPurple; 0.15 0.47 0.46];
end

function plotAblationObjectives55(T, figDir, colors)
methods = ["TNSAOO", "NSAOO", "Independent"];
labels = ["TNSAOO", "NSAOO", "Independent"];
metrics = ["makespan", "weightedEnergy", "driftPenalty"];
titles = ["Makespan / s", "Weighted energy", "Drift penalty"];

[M, E] = meanStdByCondition(T, methods, metrics);

fig = figure('Color','w','Units','pixels','Position',[100 80 1220 430]);
tl = tiledlayout(fig, 1, 3, 'TileSpacing','compact','Padding','compact');
for m = 1:numel(metrics)
    ax = nexttile(tl); hold(ax, 'on');
    for i = 1:numel(methods)
        bar(ax, i, M(i,m), 0.48, 'FaceColor', colors.fills(i,:), 'EdgeColor', colors.edges(i,:), 'LineWidth', 1.05);
        errorbar(ax, i, M(i,m), E(i,m), 'LineStyle','none', 'Color', colors.edges(i,:), 'LineWidth', 1.15, 'CapSize', 7);
    end
    hold(ax, 'off');
    setAxisCommon(ax);
    ax.XTick = 1:numel(methods); ax.XTickLabel = labels; xtickangle(ax, 22);
    ylabel(ax, titles(m)); title(ax, titles(m), 'FontWeight','normal');
end
sgtitle(tl, 'Ablation study of scheduling strategies', 'FontWeight','normal', 'FontSize', 15);
exportFigure55(fig, figDir, 'figure_ch5_5_ablation_objectives');
end

function plotAblationQuality55(T, figDir, colors)
methods = ["TNSAOO", "NSAOO", "Independent"];
labels = ["TNSAOO", "NSAOO", "Independent"];
metrics = ["HV", "IGD", "archiveSize", "conflictCount"];
titles = ["Hypervolume", "IGD", "Archive size", "Conflict count"];

[M, E] = meanStdByCondition(T, methods, metrics);

fig = figure('Color','w','Units','pixels','Position',[100 80 1320 680]);
tl = tiledlayout(fig, 2, 2, 'TileSpacing','compact','Padding','compact');
for m = 1:numel(metrics)
    ax = nexttile(tl); hold(ax, 'on');
    for i = 1:numel(methods)
        bar(ax, i, M(i,m), 0.48, 'FaceColor', colors.fills(i,:), 'EdgeColor', colors.edges(i,:), 'LineWidth', 1.05);
        errorbar(ax, i, M(i,m), E(i,m), 'LineStyle','none', 'Color', colors.edges(i,:), 'LineWidth', 1.15, 'CapSize', 7);
    end
    hold(ax, 'off');
    setAxisCommon(ax);
    ax.XTick = 1:numel(methods); ax.XTickLabel = labels; xtickangle(ax, 22);
    ylabel(ax, titles(m)); title(ax, titles(m), 'FontWeight','normal');
end
sgtitle(tl, 'Ablation study of multi-objective performance and safety', 'FontWeight','normal', 'FontSize', 15);
exportFigure55(fig, figDir, 'figure_ch5_5_ablation_quality_safety');
end

function plotTISSensitivity55(T, figDir, colors)
[vals, idxOrder] = sort(unique(T.parameterValue));
labels = arrayfun(@(x) sprintf('%.2f', x), vals, 'UniformOutput', false);
metrics = ["HV", "IGD", "makespan", "archiveSize"];
titles = ["Hypervolume", "IGD", "Makespan / s", "Archive size"];
[M, E] = meanStdByParameter(T, vals, metrics);

fig = figure('Color','w','Units','pixels','Position',[100 80 1320 680]);
tl = tiledlayout(fig, 2, 2, 'TileSpacing','compact','Padding','compact');
for m = 1:numel(metrics)
    ax = nexttile(tl); hold(ax, 'on');
    errorbar(ax, vals, M(:,m), E(:,m), '-o', 'Color', colors.deepBlue, ...
        'MarkerFaceColor', colors.softBlue, 'MarkerEdgeColor', colors.deepBlue, ...
        'LineWidth', 1.45, 'CapSize', 7, 'MarkerSize', 6);
    hold(ax, 'off');
    setAxisCommon(ax);
    xlabel(ax, 'TIS probability'); ylabel(ax, titles(m)); title(ax, titles(m), 'FontWeight','normal');
    ax.XTick = vals; ax.XTickLabel = labels;
end
sgtitle(tl, 'Sensitivity to TIS probability', 'FontWeight','normal', 'FontSize', 15);
exportFigure55(fig, figDir, 'figure_ch5_5_tis_probability_sensitivity');
end

function plotSafetySensitivity55(T, figDir, colors)
vals = sort(unique(T.parameterValue));
labels = arrayfun(@(x) sprintf('%g', x), vals, 'UniformOutput', false);
metrics = ["conflictCount", "totalWaitingTime", "makespan", "weightedEnergy"];
titles = ["Conflict count", "Waiting time / s", "Makespan / s", "Weighted energy"];
[M, E] = meanStdByParameter(T, vals, metrics);

fig = figure('Color','w','Units','pixels','Position',[100 80 1320 680]);
tl = tiledlayout(fig, 2, 2, 'TileSpacing','compact','Padding','compact');
for m = 1:numel(metrics)
    ax = nexttile(tl); hold(ax, 'on');
    errorbar(ax, vals, M(:,m), E(:,m), '-o', 'Color', colors.deepOrange, ...
        'MarkerFaceColor', colors.softOrange, 'MarkerEdgeColor', colors.deepOrange, ...
        'LineWidth', 1.45, 'CapSize', 7, 'MarkerSize', 6);
    hold(ax, 'off');
    setAxisCommon(ax);
    xlabel(ax, 'Safety distance / m'); ylabel(ax, titles(m)); title(ax, titles(m), 'FontWeight','normal');
    ax.XTick = vals; ax.XTickLabel = labels;
end
sgtitle(tl, 'Sensitivity to air-ground safety distance', 'FontWeight','normal', 'FontSize', 15);
exportFigure55(fig, figDir, 'figure_ch5_5_safety_distance_sensitivity');
end

function [M, E] = meanStdByCondition(T, conditions, metrics)
M = nan(numel(conditions), numel(metrics));
E = nan(numel(conditions), numel(metrics));
for i = 1:numel(conditions)
    idx = string(T.conditionName) == conditions(i);
    for j = 1:numel(metrics)
        x = T.(char(metrics(j)))(idx);
        M(i,j) = localMean(x); E(i,j) = localStd(x);
    end
end
end

function [M, E] = meanStdByParameter(T, vals, metrics)
M = nan(numel(vals), numel(metrics));
E = nan(numel(vals), numel(metrics));
for i = 1:numel(vals)
    idx = abs(T.parameterValue - vals(i)) < 1e-12;
    for j = 1:numel(metrics)
        x = T.(char(metrics(j)))(idx);
        M(i,j) = localMean(x); E(i,j) = localStd(x);
    end
end
end

function setAxisCommon(ax)
grid(ax, 'on'); box(ax, 'on');
ax.FontName = 'Times New Roman'; ax.FontSize = 11.5;
ax.LineWidth = 0.85; ax.GridAlpha = 0.16; ax.TickDir = 'out';
ax.YAxis.Exponent = 0;
end

function exportFigure55(fig, figDir, baseName)
set(findall(fig, '-property', 'FontName'), 'FontName', 'Times New Roman');
try
    exportgraphics(fig, fullfile(figDir, [baseName, '.png']), 'Resolution', 300);
catch
    saveas(fig, fullfile(figDir, [baseName, '.png']));
end
try
    exportgraphics(fig, fullfile(figDir, [baseName, '.pdf']), 'ContentType', 'vector');
catch
end
try
    savefig(fig, fullfile(figDir, [baseName, '.fig']));
catch
end
close(fig);
end

function y = localMean(x)
x = double(x(:)); x = x(isfinite(x)); if isempty(x), y = NaN; else, y = mean(x); end
end
function y = localStd(x)
x = double(x(:)); x = x(isfinite(x)); if numel(x) <= 1, y = 0; else, y = std(x); end
end
