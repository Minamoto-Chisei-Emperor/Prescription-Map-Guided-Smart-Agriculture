function row = addChapter55Meta(row, condition, cfg)
%ADDCHAPTER55META Add Chapter 5.5 metadata fields to one struct row.

row.experimentType = string(condition.experimentType);
row.conditionName = string(condition.conditionName);
row.method = string(condition.method);
row.runType = string(condition.runType);
row.parameterName = string(condition.parameterName);
row.parameterValue = condition.parameterValue;
row.parameterLabel = string(condition.parameterLabel);
row.tisProbability = condition.tisProbability;
row.safetyDistance_m = condition.safetyDistance;
row.enableTIS = logical(condition.enableTIS);
row.useOriginalAOOUpdate = logical(condition.useOriginalAOOUpdate);

% Always write these two fields, even if cfg.alg is missing.
% This keeps successful and failed rows structurally identical.
row.popSize = NaN;
row.maxIter = NaN;

if isfield(cfg, 'alg')
    if isfield(cfg.alg, 'popSize')
        row.popSize = cfg.alg.popSize;
    end
    if isfield(cfg.alg, 'maxIter')
        row.maxIter = cfg.alg.maxIter;
    end
end

end
