function [metricsByRun, summaryByCondition, summaryByCaseCondition, plotData] = analyzeChapter55Results(Traw, Tarchive, cfg, dataDir)
%ANALYZECHAPTER55RESULTS Compute run-level indicators and summaries.

if isempty(Traw) || height(Traw) == 0
    metricsByRun = table(); summaryByCondition = table(); summaryByCaseCondition = table(); plotData = struct(); return;
end

ok = string(Traw.status) == "ok";
TrawOk = Traw(ok,:);
if isempty(Tarchive) || height(Tarchive) == 0 || height(TrawOk) == 0
    metricsByRun = table(); summaryByCondition = table(); summaryByCaseCondition = table(); plotData = struct(); return;
end
Tarchive = Tarchive(ismember(Tarchive.runId, TrawOk.runId), :);

metricsRows = repmat(metricTemplate55(), height(TrawOk), 1);
expTypes = unique(string(TrawOk.experimentType), 'stable');

for e = 1:numel(expTypes)
    expType = expTypes(e);
    Texp = TrawOk(string(TrawOk.experimentType) == expType, :);
    caseIds = unique(Texp.caseId, 'stable');

    for c = 1:numel(caseIds)
        caseId = caseIds(c);
        caseRunIds = Texp.runId(Texp.caseId == caseId);
        arcCase = Tarchive(ismember(Tarchive.runId, caseRunIds), :);
        if isempty(arcCase), continue; end

        allObj = [arcCase.makespan, arcCase.weightedEnergy, arcCase.driftPenalty];
        [mins, maxs] = objectiveBounds55(allObj);
        refFrontRaw = nondominatedRows54(allObj);
        refFrontNorm = normalizeObjectives54(refFrontRaw, mins, maxs);

        rowIndices = find(string(TrawOk.experimentType) == expType & TrawOk.caseId == caseId);
        for ii = 1:numel(rowIndices)
            r = rowIndices(ii);
            runId = TrawOk.runId(r);
            arcRun = Tarchive(Tarchive.runId == runId, :);
            if isempty(arcRun), continue; end

            objRun = [arcRun.makespan, arcRun.weightedEnergy, arcRun.driftPenalty];
            objNorm = normalizeObjectives54(objRun, mins, maxs);
            objNorm = nondominatedRows54(objNorm);

            metricsRows(r).runId = runId;
            metricsRows(r).caseId = TrawOk.caseId(r);
            metricsRows(r).caseName = string(TrawOk.caseName(r));
            metricsRows(r).fieldName = string(TrawOk.fieldName(r));
            metricsRows(r).seed = TrawOk.seed(r);
            metricsRows(r).experimentType = string(TrawOk.experimentType(r));
            metricsRows(r).conditionName = string(TrawOk.conditionName(r));
            metricsRows(r).method = string(TrawOk.method(r));
            metricsRows(r).runType = string(TrawOk.runType(r));
            metricsRows(r).parameterName = string(TrawOk.parameterName(r));
            metricsRows(r).parameterValue = TrawOk.parameterValue(r);
            metricsRows(r).parameterLabel = string(TrawOk.parameterLabel(r));
            metricsRows(r).tisProbability = TrawOk.tisProbability(r);
            metricsRows(r).safetyDistance_m = TrawOk.safetyDistance_m(r);
            metricsRows(r).enableTIS = TrawOk.enableTIS(r);

            metricsRows(r).HV = hypervolume3D54(objNorm, [1.1, 1.1, 1.1]);
            metricsRows(r).IGD = igd54(objNorm, refFrontNorm);
            metricsRows(r).Spacing = spacing54(objNorm);
            metricsRows(r).archiveSize = height(arcRun);

            metricsRows(r).makespan = TrawOk.makespan(r);
            metricsRows(r).weightedEnergy = TrawOk.weightedEnergy(r);
            metricsRows(r).driftPenalty = TrawOk.driftPenalty(r);
            metricsRows(r).runtime_s = TrawOk.runtime_s(r);
            metricsRows(r).totalPathLength = TrawOk.totalPathLength(r);
            metricsRows(r).uavPathLength = TrawOk.uavPathLength(r);
            metricsRows(r).ugvPathLength = TrawOk.ugvPathLength(r);
            metricsRows(r).totalEnergy = TrawOk.totalEnergy(r);
            metricsRows(r).conflictCount = TrawOk.conflictCount(r);
            metricsRows(r).totalWaitingTime = TrawOk.totalWaitingTime(r);
            metricsRows(r).sprayingCoverageRate = TrawOk.sprayingCoverageRate(r);
            metricsRows(r).fertilizationCoverageRate = TrawOk.fertilizationCoverageRate(r);
        end
    end
end

metricsByRun = struct2table(metricsRows, 'AsArray', true);
metricsByRun = metricsByRun(isfinite(metricsByRun.runId), :);
writetable(metricsByRun, fullfile(dataDir, 'ch5_5_metrics_by_run.csv'));

summaryByCondition = summarizeChapter55(metricsByRun, {'experimentType','conditionName','method','parameterName','parameterValue','parameterLabel'});
writetable(summaryByCondition, fullfile(dataDir, 'ch5_5_summary_by_condition.csv'));

summaryByCaseCondition = summarizeChapter55(metricsByRun, {'experimentType','caseId','caseName','conditionName','method','parameterName','parameterValue','parameterLabel'});
writetable(summaryByCaseCondition, fullfile(dataDir, 'ch5_5_summary_by_case_condition.csv'));

% Convenience split summaries.
writetable(summaryByCondition(string(summaryByCondition.experimentType)=="ablation", :), fullfile(dataDir, 'ch5_5_ablation_summary.csv'));
writetable(summaryByCondition(string(summaryByCondition.experimentType)=="sensitivity_tis", :), fullfile(dataDir, 'ch5_5_sensitivity_tis_summary.csv'));
writetable(summaryByCondition(string(summaryByCondition.experimentType)=="sensitivity_safety", :), fullfile(dataDir, 'ch5_5_sensitivity_safety_summary.csv'));

plotData = struct();
plotData.metricsByRun = metricsByRun;
plotData.summaryByCondition = summaryByCondition;
plotData.summaryByCaseCondition = summaryByCaseCondition;
plotData.ablation = metricsByRun(string(metricsByRun.experimentType)=="ablation", :);
plotData.tisSensitivity = metricsByRun(string(metricsByRun.experimentType)=="sensitivity_tis", :);
plotData.safetySensitivity = metricsByRun(string(metricsByRun.experimentType)=="sensitivity_safety", :);
end

function row = metricTemplate55()
row = struct();
row.runId = NaN;
row.caseId = NaN;
row.caseName = "";
row.fieldName = "";
row.seed = NaN;
row.experimentType = "";
row.conditionName = "";
row.method = "";
row.runType = "";
row.parameterName = "";
row.parameterValue = NaN;
row.parameterLabel = "";
row.tisProbability = NaN;
row.safetyDistance_m = NaN;
row.enableTIS = false;

row.HV = NaN;
row.IGD = NaN;
row.Spacing = NaN;
row.archiveSize = NaN;
row.makespan = NaN;
row.weightedEnergy = NaN;
row.driftPenalty = NaN;
row.runtime_s = NaN;
row.totalPathLength = NaN;
row.uavPathLength = NaN;
row.ugvPathLength = NaN;
row.totalEnergy = NaN;
row.conflictCount = NaN;
row.totalWaitingTime = NaN;
row.sprayingCoverageRate = NaN;
row.fertilizationCoverageRate = NaN;
end

function summary = summarizeChapter55(T, groupVars)
if isempty(T) || height(T) == 0
    summary = table();
    return;
end

metrics = {'HV','IGD','Spacing','archiveSize','makespan','weightedEnergy','driftPenalty', ...
    'runtime_s','totalPathLength','uavPathLength','ugvPathLength','totalEnergy', ...
    'conflictCount','totalWaitingTime','sprayingCoverageRate','fertilizationCoverageRate'};

[G, keys] = findgroups(T(:, groupVars));
summary = keys;
summary.nRuns = splitapply(@numel, T.runId, G);

for j = 1:numel(metrics)
    v = metrics{j};
    x = T.(v);
    summary.([v '_mean']) = splitapply(@localMean, x, G);
    summary.([v '_std'])  = splitapply(@localStd, x, G);
    summary.([v '_min'])  = splitapply(@localMin, x, G);
    summary.([v '_max'])  = splitapply(@localMax, x, G);
end
end

function [mins, maxs] = objectiveBounds55(obj)
obj = obj(all(isfinite(obj),2), :);
mins = min(obj, [], 1);
maxs = max(obj, [], 1);
span = maxs - mins;
span(span < 1e-12) = 1;
maxs = mins + span;
end

function y = localMean(x)
x = double(x(:)); x = x(isfinite(x)); if isempty(x), y = NaN; else, y = mean(x); end
end
function y = localStd(x)
x = double(x(:)); x = x(isfinite(x)); if numel(x) <= 1, y = 0; else, y = std(x); end
end
function y = localMin(x)
x = double(x(:)); x = x(isfinite(x)); if isempty(x), y = NaN; else, y = min(x); end
end
function y = localMax(x)
x = double(x(:)); x = x(isfinite(x)); if isempty(x), y = NaN; else, y = max(x); end
end
