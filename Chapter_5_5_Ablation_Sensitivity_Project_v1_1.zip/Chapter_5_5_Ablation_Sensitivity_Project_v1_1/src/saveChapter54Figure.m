function saveChapter54Figure(fig, figDir, baseName)
%SAVECHAPTER54FIGURE Save FIG, PNG and PDF.

if ~exist(figDir, 'dir'), mkdir(figDir); end
try
    savefig(fig, fullfile(figDir, [baseName,'.fig']));
catch
    saveas(fig, fullfile(figDir, [baseName,'.fig']));
end
try
    exportgraphics(fig, fullfile(figDir, [baseName,'.png']), 'Resolution', 600);
catch
    print(fig, fullfile(figDir, [baseName,'.png']), '-dpng', '-r600');
end
try
    exportgraphics(fig, fullfile(figDir, [baseName,'.pdf']), 'ContentType','vector');
catch
    print(fig, fullfile(figDir, [baseName,'.pdf']), '-dpdf', '-painters');
end
end
