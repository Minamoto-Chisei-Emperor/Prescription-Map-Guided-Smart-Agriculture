function [archive, history] = mopsoOptimizer54(env, cfg)
%MOPSOOPTIMIZER54 Multi-objective particle swarm optimization baseline.

fprintf('Running MOPSO...\n');

N = cfg.alg.popSize;
nVar = cfg.env.nSprayTasks + cfg.env.nFertTasks + cfg.env.nRefillCandidates;
lb = cfg.alg.lb; ub = cfg.alg.ub;
vmax = 0.20 * (ub - lb);

pop = initializePopulation(env, cfg);
for i = 1:numel(pop)
    pop(i) = evaluateSolution(pop(i), env, cfg);
end

pbest = pop;
V = zeros(N, nVar);
archive = updateArchive([], pop, cfg);
history = initHistory54(cfg.alg.maxIter);

for iter = 1:cfg.alg.maxIter
    w = 0.75 - 0.35*(iter-1)/max(1,cfg.alg.maxIter-1);
    c1 = 1.6; c2 = 1.8;

    for i = 1:N
        leader = selectEliteFromArchive54(archive);
        r1 = rand(1,nVar);
        r2 = rand(1,nVar);

        V(i,:) = w*V(i,:) + c1*r1.*(pbest(i).position-pop(i).position) + ...
                 c2*r2.*(leader.position-pop(i).position);
        V(i,:) = max(min(V(i,:), vmax), -vmax);

        pos = pop(i).position + V(i,:);
        if rand() < 0.20
            j = randi(nVar);
            pos(j) = pos(j) + 0.10*(ub-lb)*randn();
        end

        cand = makeEvaluatedIndividual54(pos, env, cfg);
        pop(i) = cand;

        if betterIndividual(cand, pbest(i))
            pbest(i) = cand;
        end
    end

    archive = updateArchive(archive, pop, cfg);
    history = recordHistory54(history, archive, iter);
    fprintf('MOPSO iter %03d/%03d | archive=%d\n', iter, cfg.alg.maxIter, numel(archive));
end
end
