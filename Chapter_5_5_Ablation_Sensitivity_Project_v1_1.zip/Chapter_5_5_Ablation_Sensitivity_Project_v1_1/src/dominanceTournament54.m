function winner = dominanceTournament54(pop)
%DOMINANCETOURNAMENT54 Binary tournament by rank/crowding/violation.

i = randi(numel(pop));
j = randi(numel(pop));

a = pop(i);
b = pop(j);

if dominatesIndividual(a,b)
    winner = a;
elseif dominatesIndividual(b,a)
    winner = b;
else
    ca = 0; cb = 0;
    if isfield(a,'crowding'), ca = a.crowding; end
    if isfield(b,'crowding'), cb = b.crowding; end
    if ca > cb
        winner = a;
    elseif cb > ca
        winner = b;
    else
        if rand() < 0.5, winner = a; else, winner = b; end
    end
end
end
