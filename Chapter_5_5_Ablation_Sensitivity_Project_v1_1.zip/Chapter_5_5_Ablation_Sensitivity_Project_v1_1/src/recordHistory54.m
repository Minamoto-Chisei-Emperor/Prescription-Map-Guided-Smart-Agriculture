function history = recordHistory54(history, archive, iter)
%RECORDHISTORY54 Store archive statistics at one iteration.

if isempty(archive)
    return;
end

obj = reshape([archive.objectives], 3, []).';
history.bestMakespan(iter) = min(obj(:,1));
history.bestEnergy(iter) = min(obj(:,2));
history.bestDrift(iter) = min(obj(:,3));
history.archiveSize(iter) = numel(archive);
history.archiveObjsByIter{iter} = obj;
end
