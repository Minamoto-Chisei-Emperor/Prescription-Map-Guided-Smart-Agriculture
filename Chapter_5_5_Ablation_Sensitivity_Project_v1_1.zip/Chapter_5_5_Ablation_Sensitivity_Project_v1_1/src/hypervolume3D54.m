function hv = hypervolume3D54(points, ref)
%HYPERVOLUME3D54 Exact 3D hypervolume for minimization, boxes [p, ref].

if isempty(points)
    hv = 0;
    return;
end

P = points(:,1:3);
P = P(all(isfinite(P),2),:);
P = P(all(P < ref,2),:);
if isempty(P)
    hv = 0;
    return;
end

P = nondominatedRows54(P);
xs = unique([P(:,1); ref(1)]);
xs = sort(xs, 'ascend');

hv = 0;
for i = 1:numel(xs)-1
    xLeft = xs(i);
    xRight = xs(i+1);
    if xRight <= xLeft, continue; end
    active = P(P(:,1) <= xLeft + 1e-12, 2:3);
    if isempty(active), continue; end
    areaYZ = unionArea2D54(active, ref(2:3));
    hv = hv + (xRight - xLeft) * areaYZ;
end
end

function area = unionArea2D54(rectPts, refYZ)
ys = unique([rectPts(:,1); refYZ(1)]);
ys = sort(ys, 'ascend');
area = 0;
for j = 1:numel(ys)-1
    yLeft = ys(j);
    yRight = ys(j+1);
    if yRight <= yLeft, continue; end
    active = rectPts(rectPts(:,1) <= yLeft + 1e-12, :);
    if isempty(active), continue; end
    zMin = min(active(:,2));
    area = area + (yRight - yLeft) * max(0, refYZ(2) - zMin);
end
end
