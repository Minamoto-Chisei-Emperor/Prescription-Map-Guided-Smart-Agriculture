function [metricsByRun, summaryAlg, summaryCaseAlg, plotData] = analyzeChapter54Results(Traw, Tarchive, Thistory, cfg, dataDir)
%ANALYZECHAPTER54RESULTS Compute HV, IGD, spacing, summaries, and plot data.

ok = string(Traw.status) == "ok";
TrawOk = Traw(ok,:);
Tarchive = Tarchive(ismember(Tarchive.runId, TrawOk.runId), :);

metricsRows = repmat(struct(), height(TrawOk), 1);

caseIds = unique(TrawOk.caseId, 'stable');

for c = 1:numel(caseIds)
    caseId = caseIds(c);
    caseRunIds = TrawOk.runId(TrawOk.caseId == caseId);
    arcCase = Tarchive(ismember(Tarchive.runId, caseRunIds), :);

    allObj = [arcCase.makespan, arcCase.weightedEnergy, arcCase.driftPenalty];
    [mins, maxs] = objectiveBounds54(allObj);

    refFrontRaw = nondominatedRows54(allObj);
    refFrontNorm = normalizeObjectives54(refFrontRaw, mins, maxs);

    for r = 1:height(TrawOk)
        if TrawOk.caseId(r) ~= caseId
            continue;
        end

        runId = TrawOk.runId(r);
        arcRun = Tarchive(Tarchive.runId == runId, :);
        objRun = [arcRun.makespan, arcRun.weightedEnergy, arcRun.driftPenalty];
        objNorm = normalizeObjectives54(objRun, mins, maxs);
        objNorm = nondominatedRows54(objNorm);

        metricsRows(r).runId = runId;
        metricsRows(r).caseId = TrawOk.caseId(r);
        metricsRows(r).caseName = TrawOk.caseName(r);
        metricsRows(r).algorithm = TrawOk.algorithm(r);
        metricsRows(r).seed = TrawOk.seed(r);
        metricsRows(r).fieldName = TrawOk.fieldName(r);

        metricsRows(r).HV = hypervolume3D54(objNorm, [1.1,1.1,1.1]);
        metricsRows(r).IGD = igd54(objNorm, refFrontNorm);
        metricsRows(r).Spacing = spacing54(objNorm);
        metricsRows(r).archiveSize = height(arcRun);

        metricsRows(r).makespan = TrawOk.makespan(r);
        metricsRows(r).weightedEnergy = TrawOk.weightedEnergy(r);
        metricsRows(r).driftPenalty = TrawOk.driftPenalty(r);
        metricsRows(r).runtime_s = TrawOk.runtime_s(r);
        metricsRows(r).totalPathLength = TrawOk.totalPathLength(r);
        metricsRows(r).conflictCount = TrawOk.conflictCount(r);
        metricsRows(r).totalWaitingTime = TrawOk.totalWaitingTime(r);
    end
end

metricsByRun = struct2table(metricsRows, 'AsArray', true);
writetable(metricsByRun, fullfile(dataDir, 'ch5_4_metrics_by_run.csv'));

summaryAlg = summarizeByAlgorithm54(metricsByRun);
writetable(summaryAlg, fullfile(dataDir, 'ch5_4_summary_by_algorithm.csv'));

summaryCaseAlg = summarizeByCaseAlgorithm54(metricsByRun);
writetable(summaryCaseAlg, fullfile(dataDir, 'ch5_4_summary_by_case_algorithm.csv'));

% Plot data 1: HV/IGD/spacing/run metrics.
plotMetrics = metricsByRun;
writetable(plotMetrics, fullfile(dataDir, 'plot_data_ch5_4_metric_distributions.csv'));

% Plot data 2: representative Pareto front.
repCase = cfg.chapter54.representativeCaseIndex;
repSeed = cfg.chapter54.representativeSeed;
repRunIds = TrawOk.runId(TrawOk.caseId == repCase & TrawOk.seed == repSeed);
if isempty(repRunIds)
    repRunIds = TrawOk.runId(TrawOk.caseId == repCase);
end
repArchive = Tarchive(ismember(Tarchive.runId, repRunIds), :);
repObj = [repArchive.makespan, repArchive.weightedEnergy, repArchive.driftPenalty];
[repMins, repMaxs] = objectiveBounds54(repObj);
repNorm = normalizeObjectives54(repObj, repMins, repMaxs);
plotPareto = repArchive(:, {'runId','caseId','caseName','algorithm','seed','pointId'});
plotPareto.normMakespan = repNorm(:,1);
plotPareto.normEnergy = repNorm(:,2);
plotPareto.normDrift = repNorm(:,3);
plotPareto.makespan = repArchive.makespan;
plotPareto.weightedEnergy = repArchive.weightedEnergy;
plotPareto.driftPenalty = repArchive.driftPenalty;
writetable(plotPareto, fullfile(dataDir, 'plot_data_ch5_4_pareto_representative_case.csv'));

% Plot data 3: HV convergence.
plotHVConv = computeHVConvergence54(Thistory, TrawOk, cfg);
writetable(plotHVConv, fullfile(dataDir, 'plot_data_ch5_4_hv_convergence.csv'));

plotData = struct();
plotData.metricsByRun = metricsByRun;
plotData.summaryAlg = summaryAlg;
plotData.summaryCaseAlg = summaryCaseAlg;
plotData.plotMetrics = plotMetrics;
plotData.plotPareto = plotPareto;
plotData.plotHVConv = plotHVConv;
end

function summary = summarizeByAlgorithm54(T)
algs = unique(string(T.algorithm), 'stable');
metrics = {'HV','IGD','Spacing','makespan','weightedEnergy','driftPenalty','runtime_s','totalPathLength'};
rows = repmat(struct(), numel(algs), 1);
for i = 1:numel(algs)
    idx = string(T.algorithm) == algs(i);
    rows(i).algorithm = algs(i);
    rows(i).nRuns = sum(idx);
    for j = 1:numel(metrics)
        x = T.(metrics{j})(idx);
        rows(i).([metrics{j}, '_mean']) = localMean(x);
        rows(i).([metrics{j}, '_std']) = localStd(x);
        rows(i).([metrics{j}, '_min']) = localMin(x);
        rows(i).([metrics{j}, '_max']) = localMax(x);
    end
end
summary = struct2table(rows, 'AsArray', true);
end

function summary = summarizeByCaseAlgorithm54(T)
caseIds = unique(T.caseId, 'stable');
algs = unique(string(T.algorithm), 'stable');
metrics = {'HV','IGD','Spacing','makespan','weightedEnergy','driftPenalty','runtime_s','totalPathLength'};
rows = struct([]);
cnt = 0;
for c = 1:numel(caseIds)
    for a = 1:numel(algs)
        idx = T.caseId == caseIds(c) & string(T.algorithm) == algs(a);
        if ~any(idx), continue; end
        cnt = cnt + 1;
        rows(cnt).caseId = caseIds(c); %#ok<AGROW>
        first = find(idx, 1, 'first');
        rows(cnt).caseName = T.caseName(first);
        rows(cnt).algorithm = algs(a);
        rows(cnt).nRuns = sum(idx);
        for j = 1:numel(metrics)
            x = T.(metrics{j})(idx);
            rows(cnt).([metrics{j}, '_mean']) = localMean(x);
            rows(cnt).([metrics{j}, '_std']) = localStd(x);
        end
    end
end
summary = struct2table(rows, 'AsArray', true);
end

function Tout = computeHVConvergence54(Thistory, TrawOk, cfg)
if isempty(Thistory) || height(Thistory) == 0
    Tout = table();
    return;
end

caseIds = unique(TrawOk.caseId, 'stable');
rows = struct([]);
cnt = 0;

for c = 1:numel(caseIds)
    caseId = caseIds(c);
    ids = TrawOk.runId(TrawOk.caseId == caseId);
    Hcase = Thistory(ismember(Thistory.runId, ids), :);
    if isempty(Hcase), continue; end

    allObj = [Hcase.makespan, Hcase.weightedEnergy, Hcase.driftPenalty];
    [mins, maxs] = objectiveBounds54(allObj);

    algs = unique(string(Hcase.algorithm), 'stable');
    for a = 1:numel(algs)
        alg = algs(a);
        for iter = 1:cfg.chapter54.maxIter
            hvals = [];
            runIds = unique(Hcase.runId(string(Hcase.algorithm)==alg), 'stable');
            for r = 1:numel(runIds)
                Hr = Hcase(Hcase.runId == runIds(r) & Hcase.iteration == iter, :);
                if isempty(Hr), continue; end
                obj = [Hr.makespan, Hr.weightedEnergy, Hr.driftPenalty];
                objN = normalizeObjectives54(obj, mins, maxs);
                objN = nondominatedRows54(objN);
                hvals(end+1) = hypervolume3D54(objN, [1.1,1.1,1.1]); %#ok<AGROW>
            end
            if isempty(hvals), continue; end
            cnt = cnt + 1;
            rows(cnt).caseId = caseId; %#ok<AGROW>
            rows(cnt).algorithm = alg;
            rows(cnt).iteration = iter;
            rows(cnt).HV_mean = localMean(hvals);
            rows(cnt).HV_std = localStd(hvals);
        end
    end
end

if isempty(rows)
    Tout = table();
else
    Tout = struct2table(rows, 'AsArray', true);
end
end

function [mins, maxs] = objectiveBounds54(obj)
mins = min(obj, [], 1);
maxs = max(obj, [], 1);
span = maxs - mins;
span(span < 1e-12) = 1;
maxs = mins + span;
end

function y = localMean(x), x=double(x(:)); x=x(isfinite(x)); if isempty(x), y=NaN; else, y=mean(x); end, end
function y = localStd(x), x=double(x(:)); x=x(isfinite(x)); if numel(x)<=1, y=0; else, y=std(x); end, end
function y = localMin(x), x=double(x(:)); x=x(isfinite(x)); if isempty(x), y=NaN; else, y=min(x); end, end
function y = localMax(x), x=double(x(:)); x=x(isfinite(x)); if isempty(x), y=NaN; else, y=max(x); end, end
