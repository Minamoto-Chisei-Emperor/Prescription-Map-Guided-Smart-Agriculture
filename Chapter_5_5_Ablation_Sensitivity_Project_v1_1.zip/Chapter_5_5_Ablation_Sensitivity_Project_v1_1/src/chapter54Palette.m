function pal = chapter54Palette()
%CHAPTER54PALETTE Warm-muted algorithm comparison palette.

pal.tnsaoo = [0.56, 0.42, 0.72];  % muted purple
pal.nsgaii = [0.90, 0.58, 0.40];  % soft coral
pal.mopso  = [0.35, 0.61, 0.77];  % steel blue
pal.nswoa  = [0.50, 0.70, 0.45];  % sage green
pal.moead  = [0.82, 0.72, 0.36];  % muted ochre
pal.gray   = [0.42, 0.43, 0.47];
end
