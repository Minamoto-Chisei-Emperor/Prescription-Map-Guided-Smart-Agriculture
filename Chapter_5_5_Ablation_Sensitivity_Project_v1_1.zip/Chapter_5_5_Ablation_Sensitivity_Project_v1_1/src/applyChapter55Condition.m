function cfgOut = applyChapter55Condition(cfgIn, condition)
%APPLYCHAPTER55CONDITION Apply one Chapter 5.5 condition.

cfgOut = cfgIn;

cfgOut.alg.popSize = cfgIn.chapter55.popSize;
cfgOut.alg.maxIter = cfgIn.chapter55.maxIter;
cfgOut.alg.archiveSize = cfgIn.chapter55.archiveSize;

cfgOut.alg.useOriginalAOOUpdate = condition.useOriginalAOOUpdate;
cfgOut.alg.enableTIS = condition.enableTIS;
cfgOut.alg.tisProbability = condition.tisProbability;

cfgOut.conflict.safetyDistance = condition.safetyDistance;

cfgOut.chapter55.currentExperimentType = condition.experimentType;
cfgOut.chapter55.currentConditionName = condition.conditionName;
cfgOut.chapter55.currentMethod = condition.method;
cfgOut.chapter55.currentParameterName = condition.parameterName;
cfgOut.chapter55.currentParameterValue = condition.parameterValue;
cfgOut.chapter55.currentParameterLabel = condition.parameterLabel;
end
