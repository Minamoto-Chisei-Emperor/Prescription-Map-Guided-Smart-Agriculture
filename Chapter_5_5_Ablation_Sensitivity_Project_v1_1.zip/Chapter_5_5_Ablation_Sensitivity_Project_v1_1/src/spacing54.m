function val = spacing54(solution)
%SPACING54 Nearest-neighbor spacing metric; smaller is more uniform.

if size(solution,1) <= 2
    val = 0;
    return;
end

D = inf(size(solution,1),1);
for i = 1:size(solution,1)
    diff = solution - solution(i,:);
    dist = sqrt(sum(diff.^2,2));
    dist(i) = Inf;
    D(i) = min(dist);
end
val = std(D);
end
