function cfg = ensureChapter55Config(cfg)
%ENSURECHAPTER55CONFIG Fill missing fields for Chapter 5.5.
%
% Chapter 5.5 contains:
%   5.5.1 Ablation study: TNSAOO, NSAOO, Independent
%   5.5.2 Sensitivity analysis: TIS probability and safety distance

if ~isfield(cfg, 'chapter55'), cfg.chapter55 = struct(); end

% Reuse the same four representative cases as Chapter 5.4 by default.
if ~isfield(cfg.chapter55, 'caseFiles')
    if isfield(cfg, 'chapter54') && isfield(cfg.chapter54, 'caseFiles')
        cfg.chapter55.caseFiles = cfg.chapter54.caseFiles;
    else
        cfg.chapter55.caseFiles = {'ee_field_9.wkt','lt_field_258.wkt','nl_field_24.wkt','nl_field_54.wkt'};
    end
end
if ~isfield(cfg.chapter55, 'caseNames')
    if isfield(cfg, 'chapter54') && isfield(cfg.chapter54, 'caseNames')
        cfg.chapter55.caseNames = cfg.chapter54.caseNames;
    else
        cfg.chapter55.caseNames = {'Case 1: Large Estonian field','Case 2: Lithuanian field','Case 3: Dutch field A','Case 4: Dutch field B'};
    end
end

if ~isfield(cfg.chapter55, 'seeds'), cfg.chapter55.seeds = 2026; end
if ~isfield(cfg.chapter55, 'popSize'), cfg.chapter55.popSize = 20; end
if ~isfield(cfg.chapter55, 'maxIter'), cfg.chapter55.maxIter = 20; end
if ~isfield(cfg.chapter55, 'archiveSize'), cfg.chapter55.archiveSize = 50; end

if ~isfield(cfg.chapter55, 'nSprayTasks'), cfg.chapter55.nSprayTasks = [8,6,6,6]; end
if ~isfield(cfg.chapter55, 'nFertTasks'), cfg.chapter55.nFertTasks = [8,6,6,6]; end
if ~isfield(cfg.chapter55, 'nObstacles'), cfg.chapter55.nObstacles = [3,2,2,2]; end
if ~isfield(cfg.chapter55, 'nRefillCandidates'), cfg.chapter55.nRefillCandidates = [5,4,4,4]; end
if ~isfield(cfg.chapter55, 'includeKnownFieldObstacles'), cfg.chapter55.includeKnownFieldObstacles = true; end

% Ablation variants. Do not add extra variants unless required by the paper.
if ~isfield(cfg.chapter55, 'ablationMethods')
    cfg.chapter55.ablationMethods = {'TNSAOO','NSAOO','Independent'};
end

% TIS sensitivity: the TIS control parameter in the current code is
% cfg.alg.tisProbability. The default value is 0.65.
if ~isfield(cfg.chapter55, 'baselineTisProbability')
    if isfield(cfg, 'alg') && isfield(cfg.alg, 'tisProbability')
        cfg.chapter55.baselineTisProbability = cfg.alg.tisProbability;
    else
        cfg.chapter55.baselineTisProbability = 0.65;
    end
end
if ~isfield(cfg.chapter55, 'tisProbabilityValues')
    cfg.chapter55.tisProbabilityValues = [0.35, 0.50, 0.65, 0.80, 0.95];
end

% Safety distance sensitivity. The default value in config.m is 8.0 m.
if ~isfield(cfg.chapter55, 'baselineSafetyDistance')
    if isfield(cfg, 'conflict') && isfield(cfg.conflict, 'safetyDistance')
        cfg.chapter55.baselineSafetyDistance = cfg.conflict.safetyDistance;
    else
        cfg.chapter55.baselineSafetyDistance = 8.0;
    end
end
if ~isfield(cfg.chapter55, 'safetyDistanceValues')
    cfg.chapter55.safetyDistanceValues = [2, 5, 8, 10];
end

if ~isfield(cfg.chapter55, 'outputPrefix'), cfg.chapter55.outputPrefix = 'chapter5_5_ablation_sensitivity'; end
if ~isfield(cfg.chapter55, 'savePerRunMat'), cfg.chapter55.savePerRunMat = false; end
if ~isfield(cfg.chapter55, 'saveWorkspace'), cfg.chapter55.saveWorkspace = true; end

% Quick debug option. Formal experiments should keep this false.
if ~isfield(cfg.chapter55, 'quickTest'), cfg.chapter55.quickTest = false; end
if cfg.chapter55.quickTest
    cfg.chapter55.caseFiles = cfg.chapter55.caseFiles(1:min(1,numel(cfg.chapter55.caseFiles)));
    cfg.chapter55.caseNames = cfg.chapter55.caseNames(1:min(1,numel(cfg.chapter55.caseNames)));
    cfg.chapter55.seeds = cfg.chapter55.seeds(1);
    cfg.chapter55.popSize = 6;
    cfg.chapter55.maxIter = 3;
    cfg.chapter55.tisProbabilityValues = [0.50, 0.65];
    cfg.chapter55.safetyDistanceValues = [5, 8];
end

% Required defaults for random-key decoding and TNSAOO.
if ~isfield(cfg, 'alg'), cfg.alg = struct(); end
if ~isfield(cfg.alg, 'lb'), cfg.alg.lb = -5; end
if ~isfield(cfg.alg, 'ub'), cfg.alg.ub = 5; end
if ~isfield(cfg.alg, 'sigmoidThreshold'), cfg.alg.sigmoidThreshold = 0.50; end
if ~isfield(cfg.alg, 'minActiveRefill'), cfg.alg.minActiveRefill = 1; end
if ~isfield(cfg.alg, 'tisProbability'), cfg.alg.tisProbability = cfg.chapter55.baselineTisProbability; end
if ~isfield(cfg.alg, 'useOriginalAOOUpdate'), cfg.alg.useOriginalAOOUpdate = true; end
if ~isfield(cfg.alg, 'enableTIS'), cfg.alg.enableTIS = true; end
if ~isfield(cfg.alg, 'tisMode'), cfg.alg.tisMode = 'original_adapted'; end
if ~isfield(cfg.alg, 'aooStepInitial'), cfg.alg.aooStepInitial = 1.2; end
if ~isfield(cfg.alg, 'aooStepFinal'), cfg.alg.aooStepFinal = 0.15; end

if ~isfield(cfg, 'conflict'), cfg.conflict = struct(); end
if ~isfield(cfg.conflict, 'safetyDistance'), cfg.conflict.safetyDistance = cfg.chapter55.baselineSafetyDistance; end

if ~isfield(cfg, 'env'), cfg.env = struct(); end
cfg.env.includeKnownFieldObstacles = cfg.chapter55.includeKnownFieldObstacles;
end
