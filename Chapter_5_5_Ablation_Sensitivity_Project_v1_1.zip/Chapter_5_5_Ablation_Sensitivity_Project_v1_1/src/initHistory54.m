function history = initHistory54(maxIter)
%INITHISTORY54 Initialize optimization history.

history = struct();
history.bestMakespan = nan(maxIter,1);
history.bestEnergy = nan(maxIter,1);
history.bestDrift = nan(maxIter,1);
history.archiveSize = nan(maxIter,1);
history.archiveObjsByIter = cell(maxIter,1);
end
