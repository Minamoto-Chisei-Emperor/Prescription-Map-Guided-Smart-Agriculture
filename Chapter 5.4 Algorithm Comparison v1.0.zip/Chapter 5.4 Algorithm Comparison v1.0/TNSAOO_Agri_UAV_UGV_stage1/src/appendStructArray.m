function out = appendStructArray(in, add)
%APPENDSTRUCTARRAY Robustly append struct arrays.

if isempty(in)
    out = add(:);
else
    out = [in(:); add(:)];
end
end
