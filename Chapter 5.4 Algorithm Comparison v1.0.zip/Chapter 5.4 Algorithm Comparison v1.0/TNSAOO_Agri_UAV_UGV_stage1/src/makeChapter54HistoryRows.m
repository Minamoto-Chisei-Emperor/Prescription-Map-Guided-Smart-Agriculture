function rows = makeChapter54HistoryRows(runId, caseId, caseName, algName, seed, history)
%MAKECHAPTER54HISTORYROWS Store archive objective points per iteration.

rows = struct([]);
if isempty(history) || ~isfield(history, 'archiveObjsByIter')
    return;
end

cnt = 0;
template = struct('runId',NaN,'caseId',NaN,'caseName',"",'algorithm',"",'seed',NaN, ...
    'iteration',NaN,'pointId',NaN,'makespan',NaN,'weightedEnergy',NaN,'driftPenalty',NaN);

for iter = 1:numel(history.archiveObjsByIter)
    obj = history.archiveObjsByIter{iter};
    if isempty(obj), continue; end
    for p = 1:size(obj,1)
        cnt = cnt + 1;
        rows(cnt,1) = template; %#ok<AGROW>
        rows(cnt).runId = runId;
        rows(cnt).caseId = caseId;
        rows(cnt).caseName = string(caseName);
        rows(cnt).algorithm = string(algName);
        rows(cnt).seed = seed;
        rows(cnt).iteration = iter;
        rows(cnt).pointId = p;
        rows(cnt).makespan = obj(p,1);
        rows(cnt).weightedEnergy = obj(p,2);
        rows(cnt).driftPenalty = obj(p,3);
    end
end
end
